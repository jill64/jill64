export interface Env {
  D1: D1Database
}
