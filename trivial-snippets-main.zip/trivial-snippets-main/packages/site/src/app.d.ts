import type { setupD1 } from '$lib/server/setupD1'
import type { setupR2 } from '$lib/server/setupR2'
import type { D1Database, R2Bucket } from '@cloudflare/workers-types'

declare global {
  namespace App {
    interface Locals {
      D1: ReturnType<typeof setupD1>
      R2: ReturnType<typeof setupR2>
    }
    interface PageData {
      title: string
      description: string
      index?: string[]
    }
    interface Platform {
      env: {
        D1: D1Database
        R2: R2Bucket
      }
    }
  }
}
