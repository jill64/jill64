import { init } from '@jill64/sentry-sveltekit-cloudflare/client'

const onError = init(
  'https://4293d4fa1afb39f019090ae9e9350b82@o4505814639312896.ingest.sentry.io/4505842703990784'
)

export const handleError = onError()
