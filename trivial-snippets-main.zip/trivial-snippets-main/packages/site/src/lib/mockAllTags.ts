export const mockAllTags = [
  {
    name: 'Tag1',
    uid: 'eMfickC9qhdf_rr4',
    article_count: '1'
  },
  {
    name: 'Tag2',
    uid: 'l8KY9r3_4bh0dyZO',
    article_count: '32'
  },
  {
    name: 'Tag3',
    uid: 'l9KY9r3_4bh1dyZO',
    article_count: '15'
  }
]
