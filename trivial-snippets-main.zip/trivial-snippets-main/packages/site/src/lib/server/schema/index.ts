import type { ColumnType } from 'kysely'
import type { MySQLBoolean } from './types/MySQLBoolean'

type Generated<T> = T extends ColumnType<infer S, infer I, infer U>
  ? ColumnType<S, I | undefined, U>
  : ColumnType<T, T | undefined, T>

type SQLiteDate = ColumnType<Date, string, string>

interface ArticleView {
  id: Generated<number>
  article_id: number
  view: Generated<number>
}

interface ArticleTag {
  id: Generated<number>
  article_id: number
  tag_id: number
}

interface Tag {
  id: Generated<number>
  uid: string
  name: Generated<string>
}

interface ArticleEntity {
  id: Generated<number>
  article_id: number
  key: string
}

interface Article {
  id: Generated<number>
  uid: string
  markdown: Generated<string>
  title: Generated<string>
  description: Generated<string>
  is_archived: Generated<MySQLBoolean>
  published_at: SQLiteDate | null
  updated_at: SQLiteDate | null
}

export interface DB {
  article_view: ArticleView
  article_tag: ArticleTag
  tag: Tag
  article_entity: ArticleEntity
  article: Article
}
