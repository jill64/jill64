export const setupR2 = (platform: Readonly<App.Platform>) => {
  const {
    env: { R2 }
  } = platform

  const get = async (key: string) => (key ? R2.get(key) : null)

  return {
    get
  }
}
