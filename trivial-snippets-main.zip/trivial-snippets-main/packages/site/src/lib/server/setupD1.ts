import type { DB } from '$lib/server/schema'
import { Kysely, ParseJSONResultsPlugin } from 'kysely'
import { D1Dialect } from 'kysely-d1'

export const setupD1 = (platform: Readonly<App.Platform>) =>
  new Kysely<DB>({
    dialect: new D1Dialect({ database: platform.env.D1 }),
    plugins: [new ParseJSONResultsPlugin()]
  })
