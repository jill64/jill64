<script lang="ts">
  import { Paginate, calcLastPage } from '@jill64/svelte-pagination'
  import dayjs from 'dayjs'
  import type { getArticleList } from './getArticleList'

  export let title: string
  export let total: number
  export let list: Awaited<ReturnType<typeof getArticleList>>
</script>

<h1 class="text-3xl font-bold m-6 mb-3">{title}</h1>
<ul class="flex flex-col m-4">
  {#each list as article}
    <li>
      <a
        href="/article/{article.uid}"
        class="push-effect dark:pop-effect flex flex-col gap-2 p-4 rounded-lg"
      >
        <h2 class="text-2xl font-bold">
          {article.title}
        </h2>
        <div class="flex flex-wrap gap-2 items-center">
          <p class="text-sm text-zinc-500">
            {dayjs(article.published_at).format('YYYY-MM-DD')}
          </p>
          {#each article.tags ?? [] as tag}
            {#if tag}
              <span
                class="px-2 py-1 rounded-full bg-gray-400 dark:bg-gray-700 text-xs text-white dark:text-zinc-300"
              >
                {tag}
              </span>
            {/if}
          {/each}
        </div>
        <p class="text-sm text-zinc-500">
          {article.description}
        </p>
      </a>
    </li>
  {/each}
</ul>
<Paginate
  lastPage={calcLastPage({
    total,
    per: 30
  })}
  slug="[p=int]"
/>
