export const mockArticles = [
  {
    title: 'Article Title 1',
    description: 'Article Description 1',
    uid: 'izz0BCGK7WbeytU7',
    published_at: new Date(),
    view: 12,
    tags: ['Tag2']
  },
  {
    title: 'Article Title 2',
    description: 'Article Description 2',
    uid: 'VTuD0BD1lJYbA3zp',
    published_at: new Date(),
    view: 4,
    tags: []
  },
  {
    title: 'Article Title 2',
    description: 'Article Description 2',
    uid: 'VTuD0BD1lJYbA3zp',
    published_at: new Date(),
    view: 4,
    tags: ['Tag1', 'Tag2', 'Tag3']
  }
]
