import { sql } from 'kysely'

export const getArticleList = (
  D1: App.Locals['D1'],
  options: {
    p: string
    unit?: number
    tag?: string
  }
) => {
  const { tag = '', unit = 30 } = options ?? {}

  const page = parseInt(options.p)

  return D1.selectFrom('article')
    .where('article.published_at', 'is not', null)
    .where('article.is_archived', '=', 0)
    .leftJoin('article_tag', 'article.id', 'article_tag.article_id')
    .leftJoin('tag', 'article_tag.tag_id', 'tag.id')
    .$if(!!tag, (q) => q.where('tag.uid', '=', tag))
    .select(
      sql<(string | null)[] | null>`JSON_GROUP_ARRAY(DISTINCT tag.uid)`.as(
        'tags'
      )
    )
    .leftJoin('article_view', 'article.id', 'article_view.article_id')
    .select([
      'article.uid',
      'article.title',
      'article.description',
      'article.published_at',
      'article_view.view'
    ])
    .groupBy('article.id')
    .orderBy('article.published_at', 'desc')
    .offset((page - 1) * unit)
    .limit(unit)
    .execute()
}
