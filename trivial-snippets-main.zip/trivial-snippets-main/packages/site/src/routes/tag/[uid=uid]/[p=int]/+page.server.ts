import { dev } from '$app/environment'
import { getArticleList } from '$lib/getArticleList.js'
import { mockArticles } from '$lib/mockArticles.js'

export const load = ({ locals: { D1 }, params: { uid, p } }) => {
  const list = dev
    ? mockArticles
    : getArticleList(D1, {
        tag: uid,
        p
      })

  return {
    list
  }
}
