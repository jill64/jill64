<script lang="ts">
  import ArticleList from '$lib/ArticleList.svelte'

  export let data

  $: ({ list, title, matchArticleCount } = data)
</script>

<ArticleList {list} {title} total={matchArticleCount} />
