import { error } from '@sveltejs/kit'

export const load = async ({ parent, data, params: { uid } }) => {
  const { allTags } = await parent()

  const tag = allTags.find((tag) => tag.uid === uid)

  if (!tag) {
    throw error(404, 'Tag not found')
  }

  return {
    title: `Tag - ${tag.name}`,
    matchArticleCount: parseInt(tag.article_count ?? '0'),
    description: `${tag.name}に関する記事一覧`,
    ...data
  }
}
