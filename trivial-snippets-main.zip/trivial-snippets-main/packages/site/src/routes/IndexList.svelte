<script lang="ts">
  import { page } from '$app/stores'

  $: list = $page.data.index ?? []

  let current: string | undefined

  $: update = () => {
    current = list
      .slice()
      .reverse()
      .find((item) => {
        const el = document.getElementById(item)
        if (!el) return false
        const rect = el.getBoundingClientRect()
        return rect.top <= 0
      })
  }
</script>

<svelte:window on:scroll={update} />
<nav>
  <ul>
    {#each list as item}
      {@const highlight = current && current === item}
      <li>
        <a
          href="#{item}"
          class="inline-flex gap-1 w-full items-center push-effect dark:pop-effect p-2 rounded
          {highlight ? '' : 'text-zinc-600 dark:text-zinc-400 '}"
        >
          {#if highlight}
            <div class="w-0.5 h-5 mr-0.5 bg-blue-500" />
          {/if}
          {item}
        </a>
      </li>
    {/each}
  </ul>
</nav>
