<script lang="ts">
  import { page } from '$app/stores'
  import { PUBLIC_R2_HOST } from '$env/static/public'
  import {
    FlipButton,
    OGP,
    ThemeManager,
    Toaster,
    theme
  } from '@jill64/svelte-suite'
  import { HighlightSwitcher } from 'svelte-highlight-switcher'
  import '../app.postcss'
  import IndexList from './IndexList.svelte'
  import './markdown.postcss'

  export let data

  $: ({ allTags } = data)

  $: p = $page.params.p
  $: pageNum = p ? (parseInt(p) > 1 ? ` - Page ${p}` : '') : ''
  $: title = $page.data.title ? `${$page.data.title}${pageNum}` : ''

  $: description = $page.data.description
    ? $page.data.description
    : 'Trivial Snippetsは、プログラミングに関する小さな知見をまとめたブログサイトです。主にJavaScriptやTypeScriptを使用したフロントエンド技術についての記事を投稿しています。'

  $: suffix = $theme === 'dark' ? '' : '-light'

  $: isArticlePage = $page.route.id === '/article/[uid=uid]'
</script>

<ThemeManager />
<Toaster />
<OGP
  type={isArticlePage ? 'article' : 'website'}
  {title}
  site_name="Trivial Snippets"
  {description}
  image={isArticlePage
    ? `https://og-image.trivialsnippets.com/${$page.params.uid}`
    : '/og-image.png'}
/>
<HighlightSwitcher name={$theme === 'dark' ? 'githubDark' : 'github'} />

<svelte:head>
  <link rel="icon" href="/favicon{suffix}.png" />
  <link rel="icon" href="/favicon{suffix}.svg" type="image/svg+xml" />
  <link rel="apple-touch-icon" href="/apple-touch-icon{suffix}.png" />
  <link rel="preconnect" href={PUBLIC_R2_HOST} />
  <title>{title ? `${title} | ` : ''}Trivial Snippets</title>
  <meta name="description" content={description} />
</svelte:head>

<header class="flex items-center justify-between px-2 mx-2 my-1">
  <a
    href="/"
    title="Trivial Snippets"
    class="select-none push-effect dark:pop-effect rounded inline-flex p-2 gap-1 items-end font-['Helvetica']"
  >
    <span class="font-bold text-lg">{'<T/>'}</span>
    <span class="font-bold">rivial Snippets</span>
  </a>
  <FlipButton />
</header>

<main class="flex gap-6 relative mx-4">
  <div class="hidden sm:flex flex-col gap-2 w-40">
    <ul>
      {#each allTags as tag}
        {@const current = tag.uid === $page.params.uid}
        <li>
          <a
            href="/tag/{tag.uid}/1"
            class="inline-flex gap-1 w-full items-center push-effect dark:pop-effect p-2 rounded
            {current ? '' : ' text-zinc-600 dark:text-zinc-400 '}"
          >
            {#if current}
              <div class="w-0.5 h-5 mr-0.5 bg-blue-500" />
            {/if}
            {tag.name}
            <span class="text-sm text-zinc-500">
              ({tag.article_count})
            </span>
          </a>
        </li>
      {/each}
    </ul>
  </div>
  <div class="grow flex flex-col">
    <slot />
  </div>
  <div class="w-40 h-full top-4 sticky">
    <div class="hidden lg:flex flex-col gap-2">
      <IndexList />
    </div>
  </div>
</main>
