<script lang="ts">
  import { page } from '$app/stores'
</script>

<h1 class="font-bold my-4">{$page.status}</h1>
<p>{$page.error?.message ?? 'Internal Error'}</p>

<style>
  h1 {
    font-size: 2rem;
  }
</style>
