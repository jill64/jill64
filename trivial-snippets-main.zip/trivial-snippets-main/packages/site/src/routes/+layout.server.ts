import { dev } from '$app/environment'
import { mockAllTags } from '$lib/mockAllTags.js'
import { sql } from 'kysely'

export const load = ({ locals: { D1 } }) => {
  const allTags = dev
    ? mockAllTags
    : D1.selectFrom('tag')
        .leftJoin('article_tag', 'article_tag.tag_id', 'tag.id')
        .leftJoin('article', 'article.id', 'article_tag.article_id')
        .where('article.published_at', 'is not', null)
        .where('article.is_archived', '=', 0)
        .groupBy('tag.id')
        .select(['tag.name', 'tag.uid'])
        .select(
          sql<string | null>`COUNT(DISTINCT article_tag.article_id)`.as(
            'article_count'
          )
        )
        .having(sql`article_count > 0`)
        .orderBy('tag.name')
        .execute()

  const allArticleCount = dev
    ? 100
    : D1.selectFrom('article')
        .where('published_at', 'is not', null)
        .where('is_archived', '=', 0)
        .select(sql<string>`COUNT(*)`.as('count'))
        .executeTakeFirstOrThrow()
        .then((x) => parseInt(x.count))

  return {
    allTags,
    allArticleCount
  }
}
