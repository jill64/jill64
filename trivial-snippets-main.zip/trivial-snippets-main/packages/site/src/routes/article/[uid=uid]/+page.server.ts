import { dev } from '$app/environment'
import { mockAllTags } from '$lib/mockAllTags'
import { error } from '@sveltejs/kit'
import { sql } from 'kysely'
import mockMd from './mock.md?raw'

export const prerender = 'auto'

export const load = async ({ locals: { D1, R2 }, params: { uid } }) => {
  const article = dev
    ? {
        id: 1,
        title: 'Article Title',
        description: 'Article Description',
        markdown: 'Markdown Key',
        published_at: new Date(),
        view: 10,
        tags: mockAllTags
      }
    : await D1.selectFrom('article')
        .leftJoin('article_tag', 'article.id', 'article_tag.article_id')
        .leftJoin('tag', 'article_tag.tag_id', 'tag.id')
        .leftJoin('article_entity', 'article.id', 'article_entity.article_id')
        .leftJoin('article_view', 'article.id', 'article_view.article_id')
        .select([
          'article.id',
          'article.title',
          'article.description',
          'article.markdown',
          'article.published_at',
          'article_view.view'
        ])
        .select(
          sql<
            | ({
                uid: string | null
                name: string | null
              } | null)[]
            | null
          >`JSON_GROUP_ARRAY(
            JSON_OBJECT(
              'uid', tag.uid, 
              'name', tag.name
            )
          )`.as('tags')
        )
        .where('article.uid', '=', uid)
        .where('article.published_at', 'is not', null)
        .executeTakeFirstOrThrow()

  const markdown = dev
    ? mockMd
    : R2.get(article.markdown).then((res) => {
        const text = res?.text()
        if (!text) {
          throw error(404, '記事が見つかりませんでした')
        }
        return text
      })

  if (!dev) {
    await (article.view === null
      ? D1.insertInto('article_view').values({
          article_id: article.id,
          view: 1
        })
      : D1.updateTable('article_view')
          .set({
            view: article.view + 1
          })
          .where('article_id', '=', article.id)
    ).executeTakeFirstOrThrow()
  }

  return {
    title: article.title,
    description: article.description,
    article,
    markdown
  }
}
