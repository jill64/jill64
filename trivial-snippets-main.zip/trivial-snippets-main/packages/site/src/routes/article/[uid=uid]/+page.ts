export const load = ({ data }) => {
  const heads = data.markdown.match(/## (.+)\n/g) ?? []
  const index = heads.map((x) => x.replaceAll('\n', '').replace('## ', ''))

  return {
    ...data,
    index
  }
}
