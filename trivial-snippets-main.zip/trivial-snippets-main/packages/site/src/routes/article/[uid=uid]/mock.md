## Code

`Snippets`

```sh
npm i -D lodash
```

```js:index.js
console.log('Test')

const markdown = dev
  ? marked(mockMarkdown).replaceAll(
      /<code class=".+">/g,
      '<code class="hljs" >'
    )
  : R2.get(item.markdown)
      .then((res) => res?.text() ?? '')
      .then((res) => marked(res))
```

## Decoration

**Bold**

**Bold2**

_Italic_

_Italic2_

~~Strike~~

## List

1. First
   1. First
   2. Second
   3. Third
2. Second
   1. First
   2. Second
      1. First
      2. Second
      3. Third
   3. Third
3. Third

- Bullet1

  - Bullet2
  - Bullet3

- Bullet1
  - Bullet1
  - Bullet2
    1. First
    2. Second
    3. Third
  - Bullet3
- Bullet2
- Bullet3

## Quote

> # h1
>
> 文頭に`>`を置くことで引用になります。
> `複数行`にまたがる場合、改行のたびにこの記号を置く必要があります。
> **引用の上下にはリストと同じく空行がないと正しく表示されません**
> 引用の中に別の*Markdown*を使用することも可能です。
>
> > これはネストされた引用です。
