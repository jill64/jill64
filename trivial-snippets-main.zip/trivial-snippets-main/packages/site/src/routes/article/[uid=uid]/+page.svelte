<script lang="ts">
  import { toast } from '@jill64/svelte-suite'
  import dayjs from 'dayjs'
  import { codeUtility } from 'exmarkdown-code-utility'
  import { headingAnchor } from 'exmarkdown-heading-anchor'
  import Markdown from 'svelte-exmarkdown'
  import { gfmPlugin } from 'svelte-exmarkdown/gfm'

  export let data

  $: ({ article, markdown } = data)
</script>

<article class="p-2">
  <h1 class="text-4xl font-bold my-2">{article.title}</h1>
  <div class="flex flex-wrap gap-2 items-center my-2 mb-4">
    <p class="text-sm text-zinc-500">
      {dayjs(article.published_at).format('YYYY-MM-DD')}
    </p>
    {#each article.tags ?? [] as tag}
      {#if tag?.name}
        <a
          href="/tag/{tag.uid}/1"
          class="px-2 py-1 push-effect dark:pop-effect rounded-full bg-gray-400 dark:bg-gray-700 text-xs text-white dark:text-zinc-300"
        >
          {tag.name}
        </a>
      {/if}
    {/each}
  </div>
  <div class="rendered-markdown">
    <Markdown
      md={markdown}
      plugins={[
        codeUtility({
          highlight: true,
          onCopy: (promise) => {
            $toast.promise(promise, {
              loading: 'Copying...',
              success: 'Copied!',
              error: 'Failed to copy'
            })
          }
        }),
        gfmPlugin(),
        headingAnchor({
          anchor: '#'
        })
      ]}
    />
  </div>
</article>
