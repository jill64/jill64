import { dev } from '$app/environment'
import { getArticleList } from '$lib/getArticleList.js'
import { mockArticles } from '$lib/mockArticles.js'

export const load = ({ locals: { D1 }, params: { p } }) => {
  const list = dev ? mockArticles : getArticleList(D1, { p })

  return {
    list,
    title: 'All Articles',
    description: '全ての記事一覧'
  }
}
