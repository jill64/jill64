<script lang="ts">
  import ArticleList from '$lib/ArticleList.svelte'

  export let data

  $: ({ list, title, allArticleCount } = data)
</script>

<ArticleList {title} {list} total={allArticleCount} />
