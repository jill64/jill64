import { building, dev } from '$app/environment'
import { setupD1 } from '$lib/server/setupD1'
import { setupR2 } from '$lib/server/setupR2'
import { init } from '@jill64/sentry-sveltekit-cloudflare/server'
import { onRender } from '@jill64/svelte-suite'
import { sequence } from '@sveltejs/kit/hooks'

const { onError, onHandle } = init(
  'https://4293d4fa1afb39f019090ae9e9350b82@o4505814639312896.ingest.sentry.io/4505842703990784'
)

export const handle = onHandle(
  sequence(onRender(), ({ event, resolve }) => {
    const { platform } = event

    if (dev || building) {
      return resolve(event)
    }

    if (!platform) {
      throw new Error('Platform is not defined')
    }

    const D1 = setupD1(platform)
    const R2 = setupR2(platform)

    return resolve({
      ...event,
      locals: {
        D1,
        R2
      }
    })
  })
)

export const handleError = onError()
