import { expect, test } from 'vitest'
import { check } from '../check.js'

test('deny', () => {
  expect(check('https://console.trivialsnippets.com')).resolves.toBe('deny')
  expect(check('https://trivial-snippets-console.pages.dev')).resolves.toBe(
    'deny'
  )
  expect(check('https://dev.trivial-snippets-console.pages.dev')).resolves.toBe(
    'deny'
  )
})
