import { expect, test } from 'vitest'
import { check } from '../check.js'

test('pages-redirect', () => {})
