import { expect, test } from 'vitest'
import { check } from '../check.js'

test('http-redirect', () => {
  expect(check('http://console.trivialsnippets.com')).resolves.toBe(
    'http-redirect'
  )
})
