import { expect, test } from 'vitest'
import { check } from '../check.js'

test('allow', () => {
  expect(check('https://trivialsnippets.com')).resolves.toBe('allow')
  expect(check('https://trivialsnippets.com/article/1')).resolves.toBe('allow')
})
