import { expect, test } from 'vitest'
import { check } from '../check.js'

test('http-redirect', () => {
  expect(check('http://trivialsnippets.com')).resolves.toBe('http-redirect')
  expect(check('http://trivialsnippets.com/article/1')).resolves.toBe(
    'http-redirect'
  )
})
