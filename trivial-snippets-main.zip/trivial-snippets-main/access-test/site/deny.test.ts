import { expect, test } from 'vitest'
import { check } from '../check.js'

test('deny', () => {
  expect(check('https://dev.trivial-snippets.pages.dev')).resolves.toBe('deny')
})
