import { expect, test } from 'vitest'
import { check } from '../check.js'

test('pages-redirect', () => {
  expect(check('https://trivial-snippets.pages.dev')).resolves.toBe('allow')
  expect(check('https://trivial-snippets.pages.dev/article/1')).resolves.toBe(
    'allow'
  )
})
