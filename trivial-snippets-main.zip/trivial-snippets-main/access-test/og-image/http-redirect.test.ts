import { expect, test } from 'vitest'
import { check } from '../check.js'

test('http-redirect', () => {
  expect(check('http://og-image.trivialsnippets.com')).resolves.toBe(
    'http-redirect'
  )
  expect(check('http://og-image.trivialsnippets.com/article')).resolves.toBe(
    'http-redirect'
  )
})
