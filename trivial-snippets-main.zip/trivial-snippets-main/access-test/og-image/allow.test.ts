import { expect, test } from 'vitest'
import { check } from '../check.js'

test('allow', () => {
  expect(check('https://og-image.trivialsnippets.com')).resolves.toBe('404')
  expect(check('https://og-image.trivialsnippets.com/article')).resolves.toBe(
    '404'
  )
})
