import { expect, test } from 'vitest'
import { check } from '../check.js'

test('worker-redirect', () => {
  expect(
    check('https://trivial-snippets-og-image.jill64.workers.dev')
  ).resolves.toBe('allow')

  expect(
    check('https://trivial-snippets-og-image-dev.jill64.workers.dev')
  ).resolves.toBe('404')

  expect(
    check('http://trivial-snippets-og-image.jill64.workers.dev')
  ).resolves.toBe('404')

  expect(
    check('http://trivial-snippets-og-image-dev.jill64.workers.dev')
  ).resolves.toBe('404')
})
