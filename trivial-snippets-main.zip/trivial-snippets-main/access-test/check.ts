export const check = async (url: string) => {
  const dist = new URL(url)

  const response = await fetch(url, {
    redirect: 'manual',
    method: 'HEAD'
  })

  const { ok, status, headers, statusText } = response

  const location = headers.get('location')

  if (
    location?.startsWith('https://jill64.cloudflareaccess.com') &&
    status === 302
  ) {
    return 'deny'
  }

  const locationURL = location?.startsWith('http') ? new URL(location) : null

  if (
    dist.protocol === 'http:' &&
    locationURL?.protocol === 'https:' &&
    dist.host === locationURL.host
  ) {
    return 'http-redirect'
  }

  if (ok) {
    return 'allow'
  }

  if (status === 301 || status === 302) {
    return 'allow'
  }

  if (status === 404) {
    return '404'
  }

  console.error({ url, response })

  throw new Error(`${status}: ${statusText}`)
}
