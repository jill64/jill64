import { expect, test } from '@playwright/test'

test('Test', async ({ page }) => {
  await page.goto('/')
  await expect(page.getByText('rivial Snippets')).toBeVisible()
})
