import { defineConfig } from 'vitest/dist/config.js'

export default defineConfig({
  test: {
    include: ['**/*.test.ts']
  }
})
