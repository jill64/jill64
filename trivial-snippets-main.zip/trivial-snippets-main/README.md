<!----- BEGIN GHOST DOCS LOGO src="./packages/site/static/favicon.png" ----->

<div align="center">
<img src="./packages/site/static/favicon.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# trivial-snippets

[![ci.yml](https://github.com/jill64/trivial-snippets/actions/workflows/ci.yml/badge.svg)](https://github.com/jill64/trivial-snippets/actions/workflows/ci.yml) [![deploy.yml](https://github.com/jill64/trivial-snippets/actions/workflows/deploy.yml/badge.svg)](https://github.com/jill64/trivial-snippets/actions/workflows/deploy.yml) [![website](https://img.shields.io/website?up_message=working&down_message=down&url=https%3A%2F%2Ftrivialsnippets.com)](https://trivialsnippets.com)

<!----- END GHOST DOCS HEADER ----->
