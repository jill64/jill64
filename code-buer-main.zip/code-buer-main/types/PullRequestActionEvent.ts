export type PullRequestActionEvent = {
  type: 'pull_request'
}
