export type IssueActionEvent = {
  type: 'issue'
}
