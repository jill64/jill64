export const pause =
  'We are interrupting this conversation here because we have reached our token limit. Please respond with a summary based on what has been said so far and include all information that will be needed for the next conversation session.'

// Multiply by 2 to account for tokens of expected response
export const PAUSE_TOKEN = 42 * 2
