import { ChatCompletionCreateParamsBase } from 'openai/resources/chat/completions.mjs'

export type BuerRequestMessages = ChatCompletionCreateParamsBase['messages']
