import { postcssConfig } from '@jill64/svelte-tailwind'

/** @type {import('@jill64/svelte-tailwind').PostcssConfig} */
export default postcssConfig()
