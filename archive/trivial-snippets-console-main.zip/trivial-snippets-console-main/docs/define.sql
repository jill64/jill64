DROP TABLE IF EXISTS `article`;

CREATE TABLE
  IF NOT EXISTS `article` (
    `id` integer PRIMARY KEY AUTOINCREMENT,
    `uid` varchar(255) NOT NULL,
    `markdown` varchar(255) NOT NULL DEFAULT '',
    `title` varchar(255) NOT NULL DEFAULT '',
    `description` varchar(255) NOT NULL DEFAULT '',
    `is_archived` tinyint (1) NOT NULL DEFAULT 0,
    `published_at` date,
    `updated_at` date
  );

CREATE UNIQUE INDEX `article_uid_index` ON `article` (`uid`);

CREATE INDEX `article_is_archived_index` ON `article` (`is_archived`);

CREATE INDEX `article_published_at_index` ON `article` (`published_at`);

CREATE INDEX `article_updated_at_index` ON `article` (`updated_at`);

DROP TABLE IF EXISTS `article_entity`;

CREATE TABLE
  IF NOT EXISTS `article_entity` (
    `id` integer PRIMARY KEY AUTOINCREMENT,
    `article_id` integer NOT NULL,
    `key` varchar(255) NOT NULL
  );

CREATE UNIQUE INDEX `article_entity_key_index` ON `article_entity` (`key`);

DROP TABLE IF EXISTS `article_tag`;

CREATE TABLE
  IF NOT EXISTS `article_tag` (
    `id` integer PRIMARY KEY AUTOINCREMENT,
    `article_id` integer NOT NULL,
    `tag_id` integer NOT NULL
  );

CREATE UNIQUE INDEX `article_tag_article_id_tag_id_index` ON `article_tag` (`article_id`, `tag_id`);

DROP TABLE IF EXISTS `article_view`;

CREATE TABLE
  IF NOT EXISTS `article_view` (
    `id` integer PRIMARY KEY AUTOINCREMENT,
    `article_id` integer NOT NULL,
    `view` integer NOT NULL DEFAULT '0'
  );

CREATE UNIQUE INDEX `article_view_article_id_index` ON `article_view` (`article_id`);

DROP TABLE IF EXISTS `tag`;

CREATE TABLE
  IF NOT EXISTS `tag` (
    `id` integer PRIMARY KEY AUTOINCREMENT,
    `uid` varchar(255) NOT NULL,
    `name` varchar(255) NOT NULL DEFAULT ''
  );

CREATE UNIQUE INDEX `tag_uid_index` ON `tag` (`uid`);