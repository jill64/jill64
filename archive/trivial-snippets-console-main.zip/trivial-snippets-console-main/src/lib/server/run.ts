import { error } from '@sveltejs/kit'
import type { DB } from './schema'
import type { MutationQuery } from './type/MutationQuery'

export const run = async <T extends DB, TB extends keyof T, UT extends keyof T>(
  qb: MutationQuery<T, TB, UT>
) => {
  const result = await qb.executeTakeFirstOrThrow()

  if (
    'numInsertedOrUpdatedRows' in result &&
    result.numInsertedOrUpdatedRows !== 1n
  ) {
    throw error(
      500,
      `Unexpected number of rows inserted or updated : ${result.numInsertedOrUpdatedRows}`
    )
  }

  if ('numUpdatedRows' in result && result.numUpdatedRows !== 1n) {
    throw error(
      500,
      `Unexpected number of rows updated : ${result.numUpdatedRows}`
    )
  }

  if ('numDeletedRows' in result && result.numDeletedRows !== 1n) {
    throw error(
      500,
      `Unexpected number of rows deleted : ${result.numDeletedRows}`
    )
  }
}
