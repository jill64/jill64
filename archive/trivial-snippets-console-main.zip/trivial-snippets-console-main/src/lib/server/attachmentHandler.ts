import { unfurl } from '@jill64/unfurl'
import { error } from '@sveltejs/kit'
import type { ServerHandler } from './type/ServerHandler'
import { validated } from './validated'

type Arg = {
  table: 'article'
  column: 'markdown'
}

export const attachmentHandler = (arg: Arg) => {
  const { table, column } = arg

  const PUT = (async ({
    locals: { R2, D1 },
    request,
    params: { uid },
    url
  }) => {
    if (!request.body) {
      throw error(400, 'No body')
    }

    const ext = url.searchParams.get('ext')

    if (!ext) {
      throw error(400, 'No extension')
    }

    const item = await D1.selectFrom(table)
      .select(column)
      .where('uid', '=', uid)
      .executeTakeFirstOrThrow()

    const oldKey = item[column]

    const { key } = await unfurl(
      {
        key: R2.put({
          body: request.body as Parameters<typeof R2.put>[0]['body'],
          extension: ext
        })
      },
      R2.remove(oldKey)
    )

    return await validated(
      D1.updateTable(table)
        .set({ [column]: key })
        .where('uid', '=', uid)
    )
  }) satisfies ServerHandler<{
    uid: string
  }>

  const DELETE = (async ({ locals: { R2, D1 }, params: { uid } }) => {
    const item = await D1.selectFrom(table)
      .select(column)
      .where('uid', '=', uid)
      .executeTakeFirstOrThrow()

    const key = item[column]

    const { response } = await unfurl(
      {
        response: validated(
          D1.updateTable(table)
            .set({ [column]: '' })
            .where('uid', '=', uid)
        )
      },
      R2.remove(key)
    )

    return response
  }) satisfies ServerHandler<{
    uid: string
  }>

  return {
    PUT,
    DELETE
  }
}
