export const setupR2 = (platform: Readonly<App.Platform>) => {
  const {
    env: { R2 }
  } = platform

  const put = async (arg: {
    body: Parameters<typeof R2.put>[1]
    extension: string
  }) => {
    const { body, extension } = arg

    const key = `${crypto.randomUUID()}.${extension}`

    await R2.put(key, body)

    return key
  }

  const remove = async (key: string | string[] | null | undefined) => {
    if (key) {
      await R2.delete(key)
    }
  }

  const get = async (key: string) => (key ? R2.get(key) : null)

  return {
    put,
    remove,
    get
  }
}
