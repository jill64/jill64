import { text } from '@sveltejs/kit'
import isArray from 'lodash/isArray'
import { run } from './run'
import type { DB } from './schema'
import type { MutationQuery } from './type/MutationQuery'

export const validated = async <
  T extends DB,
  TB extends keyof T,
  UT extends keyof T
>(
  q: MutationQuery<T, TB, UT> | MutationQuery<T, TB, UT>[]
) => {
  await (isArray(q) ? Promise.all(q.map(run)) : run(q))

  return text('')
}
