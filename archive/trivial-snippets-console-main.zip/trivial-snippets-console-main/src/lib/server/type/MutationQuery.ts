import type {
  DeleteQueryBuilder,
  DeleteResult,
  InsertQueryBuilder,
  InsertResult,
  UpdateQueryBuilder,
  UpdateResult
} from 'kysely'
import type { DB } from '../schema'

export type MutationQuery<
  T extends DB,
  TB extends keyof T,
  UT extends keyof T
> =
  | UpdateQueryBuilder<T, TB, UT, UpdateResult>
  | DeleteQueryBuilder<T, TB, DeleteResult>
  | InsertQueryBuilder<T, TB, InsertResult>
