import type { RequestEvent } from '@sveltejs/kit'

export type ServerHandler<T extends Record<string, string> = never> = (
  event: Omit<RequestEvent, 'params'> & {
    params: T
  }
) => Promise<Response> | Response
