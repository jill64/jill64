export type MySQLBoolean = 0 | 1
