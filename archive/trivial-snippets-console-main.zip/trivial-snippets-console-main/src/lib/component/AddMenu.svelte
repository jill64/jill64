<script lang="ts">
  import { InlineModal } from '@jill64/svelte-suite'
</script>

<InlineModal let:open>
  <button
    on:click={open}
    class="push-effect dark:pop-effect border border-zinc-500 rounded-full w-7 h-7"
  >
    +
  </button>
  <div
    slot="menu"
    class="flex flex-col p-4 rounded-lg bg-zinc-800 min-w-[50vw] max-w-[80vw] min-h-[50vh] max-h-[80vh] overflow-y-auto"
  >
    <slot />
  </div>
</InlineModal>
