<script lang="ts">
  import { observable } from '@jill64/async-observer'
  import { ToggleSwitch } from '@jill64/svelte-suite/input'
  import PromiseStatusLabel from './PromiseStatusLabel.svelte'

  export let value: boolean
  export let onChange: (v: boolean) => unknown
  export let Class = ''

  const { status, observed } = observable()

  $: set = observed(onChange)
</script>

<div class="flex items-center gap-2 {Class}">
  <ToggleSwitch bind:value onChange={set}>
    <slot />
  </ToggleSwitch>
  <PromiseStatusLabel {status} />
</div>
