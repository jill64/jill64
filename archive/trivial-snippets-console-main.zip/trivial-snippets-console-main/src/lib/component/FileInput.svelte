<script lang="ts">
  import { observable } from '@jill64/async-observer'
  import { FileInput } from '@jill64/svelte-suite/input'
  import PromiseStatusLabel from './PromiseStatusLabel.svelte'

  export let accept: string
  export let onSelect: (files: FileList) => unknown
  export let Class = ''

  const { status, observed } = observable()

  $: set = observed(onSelect)
</script>

<div class="flex items-center gap-2 {Class}">
  <FileInput {accept} onSelect={set}>
    <slot />
  </FileInput>
  <PromiseStatusLabel {status} />
</div>
