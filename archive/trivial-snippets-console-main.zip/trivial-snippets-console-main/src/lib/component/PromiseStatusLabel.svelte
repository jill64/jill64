<script lang="ts">
  import type { PromiseStatus } from '@jill64/async-observer'
  import { Moon } from 'svelte-loading-spinners'
  import type { Readable } from 'svelte/store'

  export let status: Readable<PromiseStatus>
  export let Class = ''
</script>

<div class="w-7 h-7 flex items-center justify-center {Class}">
  {#if $status === 'PENDING'}
    <Moon size={24} color="#AAA" />
  {:else if $status === 'FULFILLED'}
    <span class="text-green-500 dark:text-green-700 text-xl select-none">
      ✓
    </span>
  {:else if $status === 'REJECTED'}
    ❌
  {/if}
</div>
