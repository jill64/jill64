<script lang="ts">
  import { observable } from '@jill64/async-observer'
  import { onMount } from 'svelte'
  import PromiseStatusLabel from './PromiseStatusLabel.svelte'

  export let value: string
  export let placeholder: string
  export let onLoadFocus = false
  export let Class = ''
  export let onChange: (x: string) => unknown

  let dom: HTMLInputElement | null

  onMount(() => {
    if (onLoadFocus) {
      dom?.focus()
    }
  })

  const { status, observed } = observable()

  $: set = observed(onChange)
</script>

<div class="flex items-center gap-2">
  <PromiseStatusLabel {status} />
  <input
    type="text"
    class="bg-inherit w-full focus-under p-1 text-lg border-zinc-500
	 dark:border-zinc-600 outline-none focus:border-indigo-500 {Class}"
    bind:value
    bind:this={dom}
    on:change={(x) => set(x.currentTarget.value)}
    {placeholder}
  />
</div>
