<script lang="ts">
  import { ActionButton } from '@jill64/svelte-suite/input'

  export let onClick: () => unknown
</script>

<ActionButton
  Class="w-7 h-7 text-zinc-400 rounded-full enabled:hover:bg-red-700 enabled:hover:text-white flex items-center justify-center"
  {onClick}
>
  ×
</ActionButton>
