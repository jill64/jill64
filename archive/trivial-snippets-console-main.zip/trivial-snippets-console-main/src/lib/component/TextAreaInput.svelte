<script lang="ts">
  import { observable } from '@jill64/async-observer'
  import { TextArea } from '@jill64/svelte-suite/input'
  import PromiseStatusLabel from './PromiseStatusLabel.svelte'

  export let value: string
  export let onChange: (s: string) => unknown = () => {}
  export let placeholder: string
  export let Class = ''

  const { status, observed } = observable()

  $: set = observed(onChange)
</script>

<div class="flex items-center gap-2">
  <PromiseStatusLabel {status} />
  <TextArea
    bind:value
    {placeholder}
    onChange={set}
    paddingY="4px"
    paddingX="8px"
    Class="outline-none rounded border-zinc-500 dark:border-zinc-600 text-inherit bg-inherit
    w-full outline-offset-0 focus:outline-indigo-500 {Class}"
  />
</div>
