import { page } from '$app/stores'
import { derived } from 'svelte/store'
import { request } from './request'

type FetchOption = Parameters<typeof fetch>[1]

export const action = derived([page, request], ([$page, $request]) => {
  type RequestReturn = ReturnType<typeof $request>
  function fn(path: `/${string}`): (body: BodyInit) => RequestReturn
  function fn(path: `/${string}`, option: FetchOption): RequestReturn
  function fn(path: `/${string}`, option?: FetchOption) {
    const href = `${$page.url.pathname}${path}`

    return option
      ? $request(href, {
          method: 'PUT',
          ...option
        })
      : (body: BodyInit) =>
          $request(href, {
            method: 'PUT',
            body
          })
  }

  return fn
})
