import { nanoid } from 'nanoid'

export const makeUID = () => nanoid(16)
