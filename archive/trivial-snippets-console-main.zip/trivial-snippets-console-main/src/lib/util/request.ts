import { invalidateAll } from '$app/navigation'
import { toast } from '@jill64/svelte-suite'
import { derived } from 'svelte/store'

export const request = derived(
  toast,
  ($toast) => async (href: string, option?: Parameters<typeof fetch>[1]) => {
    const response = await fetch(href, option)

    if (!response.ok) {
      const error = `Error ${response.status}: ${response.statusText}`
      $toast.error(error)
      throw new Error(error)
    }

    await invalidateAll()

    return response
  }
)
