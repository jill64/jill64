import { goto } from '$app/navigation'
import { attempt } from '@jill64/attempt'
import { toast } from '@jill64/svelte-suite'
import { derived } from 'svelte/store'

export const create = derived(
  toast,
  ($toast) => (href: string) =>
    attempt(
      async () => {
        const response = await fetch(href, { method: 'POST' })

        if (response.status !== 201) {
          return $toast.error(response.statusText)
        }

        const url = await response.text()

        await goto(url)

        $toast.success('Item Created')
      },
      (e) => $toast.error(e?.message ?? 'Unknown error')
    )
)
