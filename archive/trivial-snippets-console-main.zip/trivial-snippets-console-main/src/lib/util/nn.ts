export const nn = <T>(x: T): x is NonNullable<T> =>
  x !== null && x !== undefined
