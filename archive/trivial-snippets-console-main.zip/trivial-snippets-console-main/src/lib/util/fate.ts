export const fate = async <T>(x: T) => x
