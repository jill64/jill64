import { building, dev } from '$app/environment'
import { setupD1 } from '$lib/server/setupD1'
import { setupR2 } from '$lib/server/setupR2'
import { sequence } from '@sveltejs/kit/hooks'
import { onRender } from '@jill64/svelte-suite'

export const handle = sequence(onRender(), ({ event, resolve }) => {
  const { platform } = event

  if (dev || building) {
    return resolve(event)
  }

  if (!platform) {
    throw new Error('Platform is not defined')
  }

  const D1 = setupD1(platform)
  const R2 = setupR2(platform)

  return resolve({
    ...event,
    locals: {
      D1,
      R2
    }
  })
})
