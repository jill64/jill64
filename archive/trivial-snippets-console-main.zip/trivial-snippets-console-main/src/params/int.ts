export const match = (x) => /^\d+$/.test(x)
