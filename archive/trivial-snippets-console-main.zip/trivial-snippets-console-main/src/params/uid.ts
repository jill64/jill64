export const match = (x) => /[\w-]{16}/.test(x)
