import { makeUID } from '$lib/util/makeUID'

export const mock = [
  {
    id: 1,
    uid: makeUID(),
    markdown: '',
    title: 'Article Title',
    description: 'Article Description',
    is_archived: 0,
    published_at: null,
    updated_at: null,
    tags: ['Node.js', 'SvelteKit', 'TypeScript']
  },
  {
    id: 2,
    uid: makeUID(),
    markdown: '',
    title: 'Published Article',
    description: 'Published Description',
    is_archived: 0,
    published_at: new Date(),
    updated_at: null,
    tags: ['TailwindCSS', 'Svelte'],
    view: 0
  },
  {
    id: 3,
    uid: makeUID(),
    markdown: '',
    title: 'Updated Article',
    description: 'Updated Description',
    is_archived: 0,
    published_at: new Date(),
    updated_at: new Date(),
    tags: [],
    view: 12
  },
  {
    id: 4,
    uid: makeUID(),
    markdown: '',
    title: 'Archived Article',
    description: 'Archived Description',
    is_archived: 1,
    published_at: new Date(),
    updated_at: null,
    view: 32
  }
]
