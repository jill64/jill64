import { run } from '$lib/server/run.js'
import { makeUID } from '$lib/util/makeUID.js'
import { text } from '@sveltejs/kit'

export const POST = async ({ locals: { D1 } }) => {
  const uid = makeUID()

  await run(D1.insertInto('article').values({ uid }))

  return text(`/article/${uid}`, {
    status: 201
  })
}
