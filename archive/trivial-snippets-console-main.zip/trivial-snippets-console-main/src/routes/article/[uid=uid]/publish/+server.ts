import { validated } from '$lib/server/validated.js'
import { error } from '@sveltejs/kit'

export const POST = async ({ locals: { D1 }, params: { uid } }) => {
  const item = await D1.selectFrom('article')
    .select(['published_at', 'markdown', 'title', 'description'])
    .where('uid', '=', uid)
    .executeTakeFirstOrThrow()

  if (!item.markdown || !item.title || !item.description) {
    throw error(400, 'Article is not ready to publish')
  }

  if (item.published_at) {
    throw error(400, 'Article is already published')
  }

  return await validated(
    D1.updateTable('article')
      .set({ published_at: new Date().toISOString() })
      .where('uid', '=', uid)
  )
}
