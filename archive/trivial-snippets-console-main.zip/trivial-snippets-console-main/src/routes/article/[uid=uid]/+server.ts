import { run } from '$lib/server/run.js'
import { nn } from '$lib/util/nn.js'
import { error, text } from '@sveltejs/kit'
import { sql } from 'kysely'

export const DELETE = async ({ locals: { D1, R2 }, params: { uid } }) => {
  const { id, is_archived, keys } = await D1.selectFrom('article')
    .select(['id', 'is_archived'])
    .leftJoin('article_entity', 'article_entity.article_id', 'article.id')
    .select(
      sql<
        (string | null)[] | null
      >`JSON_GROUP_ARRAY(DISTINCT article_entity.key)`.as('keys')
    )
    .where('article.uid', '=', uid)
    .executeTakeFirstOrThrow()

  if (!is_archived) {
    throw error(400, 'Article is not archived')
  }

  await R2.remove(keys?.filter(nn))

  await Promise.all([
    run(D1.deleteFrom('article').where('id', '=', id)),
    D1.deleteFrom('article_tag')
      .where('article_id', '=', id)
      .executeTakeFirstOrThrow(),
    D1.deleteFrom('article_entity')
      .where('article_id', '=', id)
      .executeTakeFirstOrThrow(),
    D1.deleteFrom('article_view')
      .where('article_id', '=', id)
      .executeTakeFirstOrThrow()
  ])

  return text('')
}
