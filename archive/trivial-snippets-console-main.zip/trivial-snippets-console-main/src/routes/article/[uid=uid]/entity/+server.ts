import { run } from '$lib/server/run.js'
import { unfurl } from '@jill64/unfurl'
import { error, text } from '@sveltejs/kit'

export const POST = async ({
  locals: { D1, R2 },
  params: { uid },
  request,
  url
}) => {
  const extension = url.searchParams.get('ext')

  if (!extension) {
    throw error(400, 'Missing extension')
  }

  if (!request.body) {
    throw error(400, 'Missing body')
  }

  const { key, article_id } = await unfurl({
    key: R2.put({
      body: request.body as Parameters<typeof R2.put>[0]['body'],
      extension
    }),
    article_id: D1.selectFrom('article')
      .where('uid', '=', uid)
      .select('id')
      .executeTakeFirstOrThrow()
      .then((x) => x.id)
  })

  await run(D1.insertInto('article_entity').values({ article_id, key }))

  return text(key, {
    status: 201
  })
}
