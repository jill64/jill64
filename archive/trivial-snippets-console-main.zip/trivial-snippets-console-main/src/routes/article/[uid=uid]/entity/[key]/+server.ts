import { run } from '$lib/server/run.js'
import { text } from '@sveltejs/kit'

export const DELETE = async ({ locals: { D1, R2 }, params: { key } }) => {
  await Promise.all([
    run(D1.deleteFrom('article_entity').where('key', '=', key)),
    R2.remove(key)
  ])

  return text('')
}
