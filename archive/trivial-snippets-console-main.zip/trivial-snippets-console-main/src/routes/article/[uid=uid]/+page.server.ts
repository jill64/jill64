import { dev } from '$app/environment'
import { sql } from 'kysely'
import { mock } from './mock'
import mockMarkdown from './mock.md?raw'

export const load = async ({ locals: { D1, R2 }, params: { uid } }) => {
  const allTag = dev
    ? [
        { id: 1, name: 'Test1' },
        { id: 2, name: 'Test2' },
        { id: 3, name: 'Test3' },
        { id: 4, name: 'Test4' }
      ]
    : D1.selectFrom('tag').select(['id', 'name']).execute()

  const item = dev
    ? mock
    : await D1.selectFrom('article')
        .selectAll('article')
        .leftJoin('article_view', 'article_view.article_id', 'article.id')
        .select('view')
        .leftJoin('article_tag', 'article_tag.article_id', 'article.id')
        .leftJoin('tag', 'tag.id', 'article_tag.tag_id')
        .leftJoin('article_entity', 'article_entity.article_id', 'article.id')
        .select(
          sql<(string | null)[] | null>`JSON_GROUP_ARRAY(DISTINCT tag.name)`.as(
            'tags'
          )
        )
        .select(
          sql<(number | null)[] | null>`JSON_GROUP_ARRAY(DISTINCT tag.id)`.as(
            'tag_ids'
          )
        )
        .select(
          sql<
            (string | null)[] | null
          >`JSON_GROUP_ARRAY(DISTINCT article_entity.key)`.as('entity_keys')
        )
        .groupBy('article.id')
        .where('article.uid', '=', uid)
        .executeTakeFirstOrThrow()

  const markdown = dev
    ? mockMarkdown
    : R2.get(item.markdown).then((res) => res?.text() ?? '')

  return {
    item,
    streamed: {
      allTag
    },
    markdown
  }
}
