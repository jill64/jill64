import { validated } from '$lib/server/validated.js'

export const POST = async ({ locals: { D1 }, params: { uid } }) =>
  await validated(
    D1.updateTable('article').set({ is_archived: 1 }).where('uid', '=', uid)
  )
