import { mock as mockList } from '../mock'

export const mock = {
  ...mockList[0],
  tag_ids: [1, 2, 3],
  entity_keys: ['1', '2', '3']
}
