import { validated } from '$lib/server/validated.js'

export const POST = async ({ locals: { D1 }, params: { uid, tag_id } }) => {
  const article_id = await D1.selectFrom('article')
    .select('id')
    .where('uid', '=', uid)
    .executeTakeFirstOrThrow()
    .then((x) => x.id)

  return await validated(
    D1.insertInto('article_tag').values({
      article_id,
      tag_id: parseInt(tag_id)
    })
  )
}

export const DELETE = async ({ locals: { D1 }, params: { uid, tag_id } }) => {
  const article_id = await D1.selectFrom('article')
    .select('id')
    .where('uid', '=', uid)
    .executeTakeFirstOrThrow()
    .then((x) => x.id)

  return await validated(
    D1.deleteFrom('article_tag')
      .where('article_id', '=', article_id)
      .where('tag_id', '=', parseInt(tag_id))
  )
}
