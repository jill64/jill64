import { validated } from '$lib/server/validated.js'

export const PUT = async ({ locals: { D1 }, params: { uid }, request }) =>
  await validated(
    D1.updateTable('article')
      .set({ title: await request.text() })
      .where('uid', '=', uid)
  )
