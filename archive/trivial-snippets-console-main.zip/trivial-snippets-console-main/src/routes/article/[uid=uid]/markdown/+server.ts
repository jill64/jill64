import { attachmentHandler } from '$lib/server/attachmentHandler'
import { validated } from '$lib/server/validated.js'
import { unfurl } from '@jill64/unfurl'

const { PUT, DELETE } = attachmentHandler({
  table: 'article',
  column: 'markdown'
})

export { DELETE, PUT }

export const PATCH = async ({
  locals: { D1, R2 },
  params: { uid },
  request
}) => {
  const { item, text } = await unfurl({
    text: request.text(),
    item: D1.selectFrom('article')
      .select('markdown')
      .where('uid', '=', uid)
      .executeTakeFirstOrThrow()
  })

  const oldKey = item.markdown

  const { key } = await unfurl(
    {
      key: R2.put({
        body: text,
        extension: 'md'
      })
    },
    R2.remove(oldKey)
  )

  return await validated(
    D1.updateTable('article').set({ markdown: key }).where('uid', '=', uid)
  )
}
