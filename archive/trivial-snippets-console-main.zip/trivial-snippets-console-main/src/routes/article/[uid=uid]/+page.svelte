<script lang="ts">
  import { PUBLIC_R2_HOST } from '$env/static/public'
  import AddButton from '$lib/component/AddButton.svelte'
  import AddMenu from '$lib/component/AddMenu.svelte'
  import DeleteButton from '$lib/component/DeleteButton.svelte'
  import FileInput from '$lib/component/FileInput.svelte'
  import TextAreaInput from '$lib/component/TextAreaInput.svelte'
  import TextInput from '$lib/component/TextInput.svelte'
  import ToggleSwitch from '$lib/component/ToggleSwitch.svelte'
  import { action } from '$lib/util/action.js'
  import { nn } from '$lib/util/nn'
  import { toast } from '@jill64/svelte-suite'
  import { ActionButton } from '@jill64/svelte-suite/input'
  import dayjs from 'dayjs'
  import { codeUtility } from 'exmarkdown-code-utility'
  import Markdown from 'svelte-exmarkdown'
  import { gfmPlugin } from 'svelte-exmarkdown/gfm'
  import './markdown.postcss'

  export let data

  $: ({
    item,
    streamed: { allTag },
    markdown
  } = data)

  let editingMD = false
  $: draft = markdown
</script>

<div class="flex flex-col gap-4 mb-10">
  <div class="flex items-center gap-3">
    {#if item.published_at}
      {#if item.is_archived}
        <span
          class="bg-purple-500 px-2 py-1 text-xs font-bold text-white dark:bg-purple-800 rounded-full border-none"
        >
          Archived
        </span>
      {/if}
    {:else}
      <span
        class="bg-green-500 px-2 py-1 text-xs font-bold text-white dark:bg-green-800 rounded-full"
      >
        Draft
      </span>
    {/if}
    {#each (item.tags ?? []).filter(nn) as tag}
      <span
        class="bg-zinc-500 px-2 py-1 text-xs text-white dark:bg-zinc-600 rounded-full border-none"
      >
        {tag}
      </span>
    {/each}
    {#if !item.is_archived}
      <AddMenu>
        {#await allTag}
          Loading...
        {:then allTag}
          {#each allTag as tag}
            <div class="flex items-center gap-2 p-2">
              {tag.name}
              {#if item.tag_ids?.includes(tag.id)}
                <DeleteButton
                  onClick={() =>
                    $action(`/tag/${tag.id}`, { method: 'DELETE' })}
                />
              {:else}
                <AddButton
                  onClick={() => $action(`/tag/${tag.id}`, { method: 'POST' })}
                />
              {/if}
            </div>
          {/each}
        {/await}
      </AddMenu>
      {#if item.published_at}
        <ActionButton
          Class="ml-auto button text-white disabled:bg-zinc-500 disabled:dark:bg-zinc-700 bg-purple-500 push-effect dark:bg-purple-800"
          onClick={() => $action('/archive', { method: 'POST' })}
          label="Archive"
        >
          ↓
        </ActionButton>
      {:else if item.markdown && item.title && item.description}
        <ActionButton
          Class="ml-auto button text-white bg-indigo-500 push-effect disabled:bg-zinc-500 disabled:dark:bg-zinc-700"
          onClick={() => $action('/publish', { method: 'POST' })}
          label="Publish"
        >
          ✓
        </ActionButton>
      {/if}
    {/if}
  </div>
  {#if item.published_at}
    <h2>{item.title}</h2>
    <p class="text-zinc-500">
      {dayjs(item.published_at).format('YYYY-MM-DD')} - {item.view ?? 0} views
    </p>
    <p class="text-zinc-500">{item.description}</p>
  {:else}
    <TextInput
      value={item.title}
      onChange={$action('/title')}
      placeholder="Title"
    />
    <TextAreaInput
      value={item.description}
      onChange={$action('/description')}
      placeholder="Description"
    />
    {#each (item.entity_keys ?? []).filter(nn) as key}
      <div class="flex flex-wrap items-center gap-2">
        <span class="flex justify-center items-center w-10 h-10">
          {#if key}
            <img
              src="{PUBLIC_R2_HOST}/{key}"
              alt=""
              class="h-full w-full object-contain"
              loading="lazy"
            />
          {/if}
        </span>
        <ActionButton
          label="Copy"
          onClick={() => {
            navigator.clipboard.writeText(`![](${PUBLIC_R2_HOST}/${key})`)
            $toast.success('Copied')
          }}
          Class="rounded-full px-2 py-1 text-white bg-indigo-500 push-effect dark:bg-indigo-800"
        />
        <DeleteButton
          onClick={() => $action(`/entity/${key}`, { method: 'DELETE' })}
        />
      </div>
    {/each}
    <FileInput
      onSelect={async (files) => {
        const body = files[0]
        if (body) {
          const ext = body.name.split('.').pop() ?? ''
          const res = await $action(`/entity?ext=${ext}`, {
            body,
            method: 'POST'
          })
          const key = await res.text()
          const url = `${PUBLIC_R2_HOST}/${key}`
          navigator.clipboard.writeText(url)
          $toast.success('Copied to clipboard')
        }
      }}
      accept="image/*"
    >
      <div
        class="flex w-7 h-7 push-effect dark:pop-effect items-center justify-center border border-zinc-500 rounded-full"
      >
        ＋
      </div>
    </FileInput>
  {/if}
  <div class="flex items-start">
    <ToggleSwitch
      bind:value={editingMD}
      Class="sticky top-4 left-4"
      onChange={async (editing) => {
        if (!editing) {
          await $action('/markdown', { body: draft, method: 'PATCH' })
        }
      }}
    >
      <span class="ml-1 select-none"> Edit </span>
    </ToggleSwitch>
    <div class="flex flex-col items-center justify-center">
      <div class="rendered-markdown w-[80vw]">
        {#if editingMD}
          <TextAreaInput placeholder="Markdown" bind:value={draft} />
        {:else}
          <Markdown
            md={draft}
            plugins={[
              gfmPlugin(),
              codeUtility({
                highlight: true
              })
            ]}
          />
        {/if}
      </div>
    </div>
  </div>
</div>
