`Snippets`

```sh
npm i -D lodash
```

```js:index.js
console.log('Test')

const markdown = dev
  ? marked(mockMarkdown).replaceAll(
      /<code class=".+">/g,
      '<code class="hljs" >'
    )
  : R2.get(item.markdown)
      .then((res) => res?.text() ?? '')
      .then((res) => marked(res))
```

**Bold**

**Bold2**

_Italic_

_Italic2_

~~Strike~~

1. First
   1. First
   2. Second
   3. Third
2. Second
   1. First
   2. Second
      1. First
      2. Second
      3. Third
   3. Third
3. Third

- Bullet1

  - Bullet2
  - Bullet3

- Bullet1
  - Bullet1
  - Bullet2
    1. First
    2. Second
    3. Third
  - Bullet3
- Bullet2
- Bullet3

> # h1
>
> You can quote a sentence by placing `>` at the beginning of the sentence.
> If it spans multiple lines, you need to put this symbol after each line break.
> **The quotation will not display correctly unless there are blank lines above and below it, which are the same as the list.**
> It is also possible to use other _Markdown_ inside the quote.
>
> > This is a nested quote.
