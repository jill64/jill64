<script lang="ts">
  import { goto } from '$app/navigation'
  import { page } from '$app/stores'
  import { create } from '$lib/util/create.js'
  import { nn } from '$lib/util/nn.js'
  import { ActionButton } from '@jill64/svelte-suite/input'
  import { Paginate, calcLastPage } from '@jill64/svelte-pagination'
  import dayjs from 'dayjs'

  export let data

  $: ({ list, total } = data)

  $: setStatusParam = (param: string) => {
    const newURL = new URL($page.url)

    param
      ? newURL.searchParams.set('state', param)
      : newURL.searchParams.delete('state')

    goto(newURL.href)
  }

  const stateList = [
    {
      name: 'All',
      value: ''
    },
    {
      name: 'Draft',
      value: 'draft'
    },
    {
      name: 'Published',
      value: 'published'
    },
    {
      name: 'Archived',
      value: 'archived'
    }
  ]
</script>

<div class="flex gap-8">
  {#each stateList as item}
    <label
      class="flex items-center gap-1 scale-125 cursor-pointer"
      on:input={() => setStatusParam(item.value)}
    >
      <input
        type="radio"
        name="state"
        checked={$page.url.searchParams.get('state') === item.value}
      />
      {item.name}
    </label>
  {/each}
  <ActionButton
    Class="ml-auto disabled:bg-zinc-500 disabled:dark:bg-zinc-700 bg-indigo-500 enabled:push-effect button text-white"
    onClick={() => $create('/article')}
    label="Create Article"
  >
    ＋
  </ActionButton>
</div>
{#each list as item}
  <a
    href="/article/{item.uid}"
    class="flex flex-col py-3 px-2 border-b border-zinc-400 dark:border-zinc-700 push-effect dark:pop-effect"
  >
    <div class="flex items-center gap-2">
      <h3>{item.title}</h3>
      {#if !item.published_at}
        <span
          class="bg-green-500 text-white px-2 py-1 text-xs font-bold dark:bg-green-800 rounded-full border-none"
        >
          Draft
        </span>
      {/if}
      {#if item.is_archived}
        <span
          class="bg-purple-500 text-white px-2 py-1 text-xs font-bold dark:bg-purple-800 rounded-full border-none"
        >
          Archived
        </span>
      {/if}
      {#each (item.tags ?? []).filter(nn) as tag}
        <span
          class="bg-zinc-500 text-white px-2 py-1 text-xs dark:bg-zinc-600 rounded-full border-none"
        >
          {tag}
        </span>
      {/each}
    </div>
    {#if item.published_at}
      <p class="text-zinc-500">
        {dayjs(item.published_at).format('YYYY-MM-DD')} - {item.view ?? 0} views
      </p>
    {/if}
    <p class="text-zinc-500">{item.description}</p>
  </a>
{/each}
<Paginate
  lastPage={calcLastPage({
    total,
    per: 30
  })}
  slug="[p=int]"
/>
