import { dev } from '$app/environment'
import { sql } from 'kysely'
import { mock } from '../mock.js'

export const load = ({ locals: { D1 }, params: { p }, url }) => {
  const state = url.searchParams.get('state')

  if (dev) {
    return {
      total: 100,
      list: mock
    }
  }

  const q = D1.selectFrom('article')
    .$if(state === 'draft', (q) => q.where('article.published_at', 'is', null))
    .$if(state === 'published', (q) =>
      q.where('article.published_at', 'is not', null)
    )
    .$if(state === 'archived', (q) => q.where('article.is_archived', '=', 1))

  const list = q
    .selectAll('article')
    .leftJoin('article_view', 'article_view.article_id', 'article.id')
    .select('view')
    .leftJoin('article_tag', 'article_tag.article_id', 'article.id')
    .leftJoin('tag', 'tag.id', 'article_tag.tag_id')
    .select(
      sql<(string | null)[] | null>`JSON_GROUP_ARRAY(DISTINCT tag.name)`.as(
        'tags'
      )
    )
    .orderBy('article.published_at', 'desc')
    .orderBy('article.id', 'desc')
    .groupBy('article.id')
    .offset((Number(p) - 1) * 30)
    .limit(30)
    .execute()

  const total = q
    .select(sql<string>`COUNT(*)`.as('total'))
    .executeTakeFirstOrThrow()
    .then((x) => Number(x.total))

  return {
    total,
    list
  }
}
