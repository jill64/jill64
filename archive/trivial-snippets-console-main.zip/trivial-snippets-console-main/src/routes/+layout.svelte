<script lang="ts">
  import { page } from '$app/stores'
  import { PUBLIC_R2_HOST } from '$env/static/public'
  import {
    FlipButton,
    ThemeManager,
    Toaster,
    theme
  } from '@jill64/svelte-suite'
  import { HighlightSwitcher } from 'svelte-highlight-switcher'
  import '../app.postcss'

  $: suffix = $theme === 'dark' ? '' : '-light'
</script>

<svelte:head>
  <link href={PUBLIC_R2_HOST} rel="preconnect" />
  <link rel="icon" href="/favicon{suffix}.svg" type="image/svg+xml" />
  <link rel="icon" href="/favicon{suffix}.png" />
  <link rel="icon" href="/favicon{suffix}.ico" />
  <link rel="apple-touch-icon" href="/apple-touch-icon{suffix}.png" />
</svelte:head>

<HighlightSwitcher name={$theme === 'dark' ? 'githubDark' : 'github'} />
<Toaster />
<ThemeManager />

<header
  class="border-b px-2 flex items-center justify-between border-zinc-300 dark:border-zinc-700"
>
  <a
    href="/"
    class="select-none inline-flex p-2 items-end gap-1 font-['Helvetica']"
  >
    <span class="font-bold text-lg">{'<T/>'}</span>
    rivial Snippets Console
  </a>
  <FlipButton />
</header>
<ul class="text-3xl flex gap-6 mt-4 mb-8">
  <li>
    <a
      href="/article"
      class="border-b-2 p-2
			{$page.url.pathname.startsWith('/article')
        ? 'border-indigo-500'
        : 'border-transparent hover:border-indigo-500 text-zinc-500'}"
    >
      Article
    </a>
  </li>
  <li>
    <a
      href="/tag"
      class="border-b-2 p-2
			{$page.url.pathname.startsWith('/tag')
        ? 'border-indigo-500'
        : 'border-transparent hover:border-indigo-500 text-zinc-500'}"
    >
      Tag
    </a>
  </li>
</ul>

<slot />
