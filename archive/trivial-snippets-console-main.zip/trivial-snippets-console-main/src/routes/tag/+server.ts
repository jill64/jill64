import { run } from '$lib/server/run.js'
import { makeUID } from '$lib/util/makeUID.js'
import { text } from '@sveltejs/kit'

export const POST = async ({ locals: { D1 } }) => {
  const uid = makeUID()

  await run(D1.insertInto('tag').values({ uid }))

  return text(`/tag/${uid}`, {
    status: 201
  })
}
