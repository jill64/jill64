import { dev } from '$app/environment'
import { sql } from 'kysely'
import { mock } from './mock.js'

export const load = ({ locals: { D1 } }) => {
  const list = dev
    ? mock
    : D1.selectFrom('tag')
        .selectAll('tag')
        .leftJoin('article_tag', 'tag.id', 'article_tag.tag_id')
        .select(sql<number | null>`COUNT(article_tag.id)`.as('used'))
        .groupBy('tag.id')
        .execute()

  return {
    list
  }
}
