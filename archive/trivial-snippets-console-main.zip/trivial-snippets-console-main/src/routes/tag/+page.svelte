<script lang="ts">
  import { create } from '$lib/util/create.js'
  import { ActionButton } from '@jill64/svelte-suite/input'

  export let data

  $: ({ list } = data)
</script>

<div class="flex">
  <ActionButton
    Class="ml-auto disabled:bg-zinc-500 disabled:dark:bg-zinc-700 bg-indigo-500 enabled:push-effect button text-white"
    onClick={() => $create('/tag')}
    label="Create Tag"
  >
    ＋
  </ActionButton>
</div>
{#each list as item}
  <a
    href="/tag/{item.uid}"
    class="flex items-center gap-2 py-3 px-2 border-b border-zinc-400 dark:border-zinc-700 push-effect dark:pop-effect"
  >
    <div>
      <h3>{item.name}</h3>
      {#if item.used}
        <p class="text-zinc-500">{item.used} used</p>
      {/if}
    </div>
  </a>
{/each}
