import { run } from '$lib/server/run.js'
import { unfurl } from '@jill64/unfurl'
import { error, text } from '@sveltejs/kit'

export const DELETE = async ({ locals: { D1 }, params: { uid } }) => {
  const { used, item } = await unfurl({
    used: D1.selectFrom('article_tag')
      .select('article_tag.id')
      .leftJoin('tag', 'tag.id', 'article_tag.tag_id')
      .where('tag.uid', '=', uid)
      .executeTakeFirst(),
    item: D1.selectFrom('tag')
      .select('id')
      .where('uid', '=', uid)
      .executeTakeFirstOrThrow()
  })

  if (used) {
    throw error(400, 'Tag is used by articles')
  }

  const id = item.id

  await Promise.all([
    run(D1.deleteFrom('tag').where('id', '=', id)),
    D1.deleteFrom('article_tag')
      .where('tag_id', '=', id)
      .executeTakeFirstOrThrow()
  ])

  return text('')
}
