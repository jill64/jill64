import { dev } from '$app/environment'
import { sql } from 'kysely'
import { mock } from './mock'

export const load = ({ locals: { D1 }, params: { uid } }) => {
  const item = dev
    ? mock
    : D1.selectFrom('tag')
        .selectAll('tag')
        .leftJoin('article_tag', 'tag.id', 'article_tag.tag_id')
        .select(sql<number | null>`COUNT(article_tag.id)`.as('used'))
        .groupBy('tag.id')
        .where('tag.uid', '=', uid)
        .executeTakeFirstOrThrow()

  return {
    item
  }
}
