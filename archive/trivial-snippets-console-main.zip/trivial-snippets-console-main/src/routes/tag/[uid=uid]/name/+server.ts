import { validated } from '$lib/server/validated.js'

export const PUT = async ({ locals: { D1 }, params: { uid }, request }) =>
  await validated(
    D1.updateTable('tag')
      .set({
        name: await request.text()
      })
      .where('uid', '=', uid)
  )
