import { mock as mockList } from '../mock'

export const mock = mockList[1]
