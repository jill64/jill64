<script lang="ts">
  import { goto } from '$app/navigation'
  import TextInput from '$lib/component/TextInput.svelte'
  import { action } from '$lib/util/action.js'
  import { request } from '$lib/util/request.js'
  import { ActionButton } from '@jill64/svelte-suite/input'
  import { Trash2Icon } from '@jill64/svelte-suite/icons'

  export let data

  $: ({ item } = data)
</script>

<div class="flex flex-col gap-4">
  <TextInput
    value={item.name}
    placeholder="Tag Name"
    onChange={$action('/name')}
  />
  <p class="text-zinc-500">{item.used ?? 0} used</p>
  {#if !item.used}
    <ActionButton
      Class="button ml-auto stroke-2 stroke-black dark:stroke-[#EEE] enabled:hover:bg-red-700 disabled:bg-zinc-300 disabled:dark:bg-zinc-700 enabled:hover:text-white enabled:hover:stroke-white border-2 enabled:border-red-700 disabled:border-transparent"
      onClick={async () => {
        await $request(`/tag/${item.uid}`, { method: 'DELETE' })
        await goto('/tag')
      }}
      label="Delete Tag"
    >
      <Trash2Icon />
    </ActionButton>
  {/if}
</div>
