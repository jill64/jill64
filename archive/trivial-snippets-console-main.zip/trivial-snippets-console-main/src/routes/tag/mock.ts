import { makeUID } from '$lib/util/makeUID'

export const mock = [
  {
    id: 1,
    uid: makeUID(),
    name: 'Node.js',
    used: 2
  },
  {
    id: 2,
    uid: makeUID(),
    name: 'Svelte'
  },
  {
    id: 3,
    uid: makeUID(),
    name: 'Tailwind CSS',
    used: 23
  }
]
