<!----- BEGIN GHOST DOCS LOGO src="./static/favicon.png" ----->

<div align="center">
<img src="./static/favicon.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# trivial-snippets-console

[![website](https://img.shields.io/website?up_message=working&down_message=down&url=https%3A%2F%2Fconsole.trivialsnippets.com)](https://console.trivialsnippets.com)

Trivial Snippets Management Console

<!----- END GHOST DOCS HEADER ----->
