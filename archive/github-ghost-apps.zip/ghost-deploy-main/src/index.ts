import { octoflare } from 'octoflare'

export default octoflare(async ({ payload, installation }) => {
  if (!('commits' in payload)) {
    return new Response('Skip Deploy: No Push Event', {
      status: 200
    })
  }

  if (!installation) {
    return new Response('Skip Deploy: No Installation', {
      status: 200
    })
  }

  const head_sha = payload.after

  if (Number(head_sha) === 0) {
    return new Response('Skip Deploy: Head SHA = 0', {
      status: 200
    })
  }

  const { repository, ref } = payload

  if (ref.replace('refs/heads/', '') !== repository.default_branch) {
    return new Response('Skip Deploy: Not Default Branch', {
      status: 200
    })
  }

  const repo = repository.name
  const owner = repository.owner.login

  const result = await installation.getFile('wrangler.toml')

  if (!result?.data) {
    return new Response('Skip Deploy: No Wrangler.toml', {
      status: 200
    })
  }

  const { dispatchWorkflow } = await installation.createCheckRun({
    repo,
    owner,
    name: 'Ghost Deploy',
    head_sha
  })

  await dispatchWorkflow()

  return new Response('Ghost Deploy Workflow Dispatched', {
    status: 202
  })
})
