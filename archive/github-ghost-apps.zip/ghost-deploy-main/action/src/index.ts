import exec from '@actions/exec'
import { action } from 'octoflare/action'

action(async () => {
  const result = await exec.getExecOutput('npm run deploy', undefined, {
    ignoreReturnCode: true
  })

  if (result.exitCode === 0) {
    return 'success'
  }

  return {
    conclusion: 'failure',
    output: {
      title: 'Deploy Failed',
      summary: `
## stdout
\`\`\`
${result.stdout}
\`\`\`

## stderr
\`\`\`
${result.stderr}
\`\`\`
`
    }
  }
})
