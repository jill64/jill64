<!----- BEGIN GHOST DOCS LOGO src="./assets/logo.png" ----->

<div align="center">
<img src="./assets/logo.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# Ghost Deploy

[![ghost-deploy.yml](https://github.com/jill64/ghost-deploy/actions/workflows/ghost-deploy.yml/badge.svg)](https://github.com/jill64/ghost-deploy/actions/workflows/ghost-deploy.yml) [![github-app](https://img.shields.io/badge/GitHub_App-Ghost_Deploy-midnightblue)](https://github.com/apps/ghost-deploy) [![octoflare](https://img.shields.io/badge/framework-🌤️Octoflare-dodgerblue)](https://github.com/jill64/octoflare)

👻 Detect Platform, Ship Codes, In the Dark.

<!----- END GHOST DOCS HEADER ----->

## Supported Platforms

| Provider   | Trigger         | Command          | Credential           |
| ---------- | --------------- | ---------------- | -------------------- |
| Cloudflare | `wrangler.toml` | `npm run deploy` | CLOUDFLARE_API_TOKEN |
