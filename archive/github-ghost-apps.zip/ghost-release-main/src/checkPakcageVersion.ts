import { attempt } from '@jill64/attempt'
import { Octokit } from 'octoflare/octokit'
import { Buffer } from 'node:buffer'

export const checkPakcageVersion = async ({
  repo,
  owner,
  octokit
}: {
  repo: string
  owner: string
  octokit: Octokit
}) => {
  const response = await attempt(
    () =>
      octokit.rest.repos.getContent({
        owner,
        repo,
        path: 'package.json'
      }),
    null
  )

  if (!response?.data) {
    return new Response('No package.json', {
      status: 200
    })
  }

  const { data } = response

  if (!('type' in data && data.type === 'file')) {
    return new Response('Invalid file type', {
      status: 200
    })
  }

  const text =
    data.encoding === 'base64'
      ? Buffer.from(data.content, 'base64').toString()
      : data.content

  const json = attempt(() => JSON.parse(text) as unknown, null)

  if (!json) {
    return new Response('Invalid JSON', {
      status: 200
    })
  }

  if (!(typeof json === 'object' && 'version' in json)) {
    return new Response('No version field', {
      status: 200
    })
  }

  const { version } = json

  if (typeof version !== 'string') {
    return new Response('Invalid version field', {
      status: 200
    })
  }

  return null
}
