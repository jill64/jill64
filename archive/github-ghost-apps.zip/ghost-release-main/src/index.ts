import { octoflare } from 'octoflare'
import { checkPakcageVersion } from './checkPakcageVersion.js'

export default octoflare(async ({ payload, installation }) => {
  if (!('commits' in payload)) {
    return new Response('Skip Release: No Push Event', {
      status: 200
    })
  }

  if (!installation) {
    return new Response('Skip Release: No Installation', {
      status: 200
    })
  }

  const { repository, ref } = payload

  if (ref.replace('refs/heads/', '') !== repository.default_branch) {
    return new Response('Skip Release: No Default Branch', {
      status: 200
    })
  }

  const repo = repository.name
  const owner = repository.owner.login

  const response = await checkPakcageVersion({
    repo,
    owner,
    octokit: installation.kit
  })

  if (response) {
    return response
  }

  const { dispatchWorkflow } = await installation.createCheckRun({
    name: 'Ghost Release',
    head_sha: payload.after,
    repo,
    owner
  })

  await dispatchWorkflow()

  return new Response('Ghost Release Workflow Dispatched', {
    status: 202
  })
})
