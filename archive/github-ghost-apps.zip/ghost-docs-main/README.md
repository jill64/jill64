<!----- BEGIN GHOST DOCS LOGO src="./assets/logo.png" ----->

<div align="center">
<img src="./assets/logo.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# Ghost Docs

[![ci.yml](https://github.com/jill64/ghost-docs/actions/workflows/ci.yml/badge.svg)](https://github.com/jill64/ghost-docs/actions/workflows/ci.yml) [![github-app](https://img.shields.io/badge/GitHub_App-Ghost_Docs-midnightblue)](https://github.com/apps/ghost-docs) [![octoflare](https://img.shields.io/badge/framework-🌤️Octoflare-dodgerblue)](https://github.com/jill64/octoflare)

👻 Read Repo, Sync Docs, In the Dark.

<!----- END GHOST DOCS HEADER ----->

## Repo Reference

- Name
- Description
- URL
  - github.io
  - stackblitz.com
- Topics
  - github-app
  - web-app
- File
  - .github
    - workflows
      - `*.yml`
        - `/.github/workflows/run-vitest.yml`
  - package.json
    - name
    - description
    - devDependencies
      - octoflare

## Sync Docs

### Logo

```md
<!----- BEGIN GHOST DOCS LOGO src="./assets/logo.png" ----->
<!----- END GHOST DOCS LOGO ----->
```

### Header

```md
<!----- BEGIN GHOST DOCS HEADER ----->
<!----- END GHOST DOCS HEADER ----->
```
