import { OctoflareInstallation } from 'octoflare'
import { WebhookEvent } from 'octoflare/webhook'

export const validation = async ({
  payload,
  installation
}: {
  payload: WebhookEvent
  installation: OctoflareInstallation | null
}) => {
  if (!installation) {
    return new Response('Skip Sync: No Installation', {
      status: 200
    })
  }

  const isRepoEvent =
    'action' in payload &&
    'changes' in payload &&
    payload.action === 'edited' &&
    'repository' in payload &&
    payload.repository

  const isPushEvent = 'commits' in payload

  if (!isRepoEvent && !isPushEvent) {
    return new Response('Skip Sync: No Trigger Event', {
      status: 200
    })
  }

  const { repository, sender } = payload

  if (!repository) {
    return new Response('Skip Sync: No Repository', {
      status: 200
    })
  }

  const repo = repository.name
  const owner = repository.owner.login

  if (
    sender.login === 'ghost-format[bot]' ||
    sender.login === 'ghost-docs[bot]'
  ) {
    return new Response('Skip Sync: Push by Ghost Format', {
      status: 200
    })
  }

  const isTriggered = isPushEvent
    ? payload.commits.some((commit) => {
        const changes = [...commit.modified, ...commit.added, ...commit.removed]
        return (
          changes.includes('package.json') ||
          changes.includes('README.md') ||
          changes.some((file) => file.startsWith('.github/workflows'))
        )
      })
    : true

  if (!isTriggered) {
    return new Response('Skip Sync: No Changes', {
      status: 200
    })
  }

  const octokit = installation.kit

  const ref = isPushEvent
    ? payload.ref.replace('refs/heads/', '')
    : repository.default_branch

  const head_sha = isPushEvent ? payload.after : null

  if (head_sha && Number(head_sha) !== 0) {
    await installation.createCheckRun({
      name: 'Ghost Docs',
      head_sha,
      repo,
      owner
    })
  }

  return {
    repo,
    owner,
    ref,
    repository,
    octokit,
    isPushEvent
  }
}
