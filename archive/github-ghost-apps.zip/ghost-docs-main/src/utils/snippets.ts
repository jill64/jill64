export const BEGIN_FIRST = '<!----- BEGIN GHOST DOCS'
export const END_FIRST = '<!----- END GHOST DOCS'
export const LAST_TAIL = '----->'
