<!----- BEGIN GHOST DOCS LOGO src="./assets/logo.png" ----->

<div align="center">
<img src="./assets/logo.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# Semantic Manager

[![github-app](https://img.shields.io/badge/GitHub_App-Semantic_Manager-midnightblue)](https://github.com/apps/semantic-manager) [![octoflare](https://img.shields.io/badge/framework-🌤️Octoflare-dodgerblue)](https://github.com/jill64/octoflare)

✅ Automated semantic version bump

<!----- END GHOST DOCS HEADER ----->

## Check Version Integrity

For each pull request event (open, sync, reopen), check if the version is up-to-date.

Head Version > Base Version

If the condition is not met, version bumping is performed and pushed based on the latest version with the following conditions.

| type  | PR title prefix (case insensitive) |
| ----- | ---------------------------------- |
| major | `breaking:`, `major:`              |
| minor | `feat:`, `minor:`                  |
| patch | `fix:`, other...                   |
