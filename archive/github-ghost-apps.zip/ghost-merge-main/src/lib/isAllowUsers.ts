import { Octokit } from 'octoflare/octokit'
import { array, boolean, optional, scanner, string } from 'typescanner'

const isConfig = scanner({
  owner: optional(boolean),
  role: optional(
    scanner({
      admin: optional(boolean)
    })
  ),
  users: optional(array(string))
})

const defaultAllowUsers = [
  'dependabot[bot]',
  'renovate[bot]',
  'ghost-docs[bot]'
]

export const isAllowUsers = async ({
  name,
  owner,
  ownerType,
  octokit,
  config
}: {
  name: string | undefined
  ownerType: string
  octokit: Octokit
  owner: string
  config: unknown
}) => {
  if (!name) {
    throw new Error('name is undefined')
  }

  const conf = isConfig(config) ? config : null

  if ((conf?.users ?? defaultAllowUsers).includes(name)) {
    return true
  }

  if ((conf?.owner !== undefined ? conf.owner : true) && name === owner) {
    return true
  }

  if (ownerType !== 'Organization') {
    return false
  }

  const {
    data: { role }
  } = await octokit.rest.orgs.getMembershipForUser({
    org: owner,
    username: name
  })

  return (
    (conf?.role?.admin !== undefined ? conf.role.admin : true) &&
    role === 'admin'
  )
}
