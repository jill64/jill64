import { Octokit } from 'octoflare/octokit'

export const enableAutoMerge = async ({
  pull_number,
  octokit,
  repo,
  owner
}: {
  pull_number: number
  octokit: Octokit
  repo: string
  owner: string
}) => {
  const {
    repository: {
      pullRequest: { id: pullRequestId }
    }
  } = await octokit.graphql<{
    repository: { pullRequest: { id: string } }
  }>(/* GraphQL */ `
    query Query {
      repository(name: "${repo}", owner: "${owner}") {
        pullRequest(number: ${pull_number}) {
          id
        }
      }
    }
  `)

  try {
    await octokit.graphql(/* GraphQL */ `
    mutation MyMutation {
      enablePullRequestAutoMerge(input: { pullRequestId: "${pullRequestId}" }) {
        clientMutationId
      }
    }
  `)
  } catch {
    await octokit.rest.pulls.merge({
      repo,
      owner,
      pull_number
    })
  }
}
