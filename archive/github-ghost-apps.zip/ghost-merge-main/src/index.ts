import { octoflare } from 'octoflare'
import yaml from 'yaml'
import { enableAutoMerge } from './lib/enableAutoMerge.js'
import { isAllowUsers } from './lib/isAllowUsers.js'

export default octoflare(async ({ payload, installation }) => {
  if (!installation) {
    return new Response('Skip Merge: No Installation', {
      status: 200
    })
  }

  if (!('pull_request' in payload)) {
    return new Response('Skip Merge: No PR Event', {
      status: 200
    })
  }

  const { repository, pull_request, action } = payload

  if (
    action !== 'opened' &&
    action !== 'reopened' &&
    action !== 'synchronize'
  ) {
    return new Response('Skip Merge: No Target Event', {
      status: 200
    })
  }

  const owner = repository.owner.login
  const repo = repository.name

  await installation.createCheckRun({
    owner,
    repo,
    name: 'Ghost Merge',
    head_sha: pull_request.head.sha
  })

  const config = await installation.getFile('ghost-merge.yml', {
    parser: (x) => yaml.parse(x) as unknown
  })

  const allow = await isAllowUsers({
    name: pull_request.user.login,
    owner,
    ownerType: repository.owner.type,
    octokit: installation.kit,
    config: config?.data
  })

  if (!allow) {
    return {
      conclusion: 'skipped',
      output: {
        title: 'Not Allowed',
        summary: 'This user is not allowed to merge.'
      }
    }
  }

  try {
    const response = await installation.kit.rest.repos.getBranchProtection({
      owner,
      repo,
      branch: pull_request.base.ref
    })

    if (response.data.required_status_checks?.checks.length) {
      await enableAutoMerge({
        pull_number: pull_request.number,
        octokit: installation.kit,
        repo,
        owner
      })

      return 'success'
    }
  } catch (e) {
    console.error(e)
  }

  return {
    conclusion: 'skipped',
    output: {
      title: 'No Status Checks',
      summary: 'This repository does not have required status checks.'
    }
  }
})
