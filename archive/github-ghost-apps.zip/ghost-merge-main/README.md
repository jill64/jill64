<!----- BEGIN GHOST DOCS LOGO src="./assets/logo.png" ----->

<div align="center">
<img src="./assets/logo.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# Ghost Merge

[![github-app](https://img.shields.io/badge/GitHub_App-Ghost_Merge-midnightblue)](https://github.com/apps/ghost-merge) [![octoflare](https://img.shields.io/badge/framework-🌤️Octoflare-dodgerblue)](https://github.com/jill64/octoflare)

👻 Check Author, Merge PR, In the Dark.

<!----- END GHOST DOCS HEADER ----->

- ✅ Resolve the issue of `github-actions[bot]` not triggering CI.
- ✅ It is no longer necessary to set a unique APP_ID for every repository.
- ✅ Some bots can close PRs without human intervention.

This app automatically performs a merge when a particular user creates a pull request in an environment where branch protection is enabled.

## Default Allowed Users

- repository owner
- organization admin
- `renovate[bot]`
- `dependabot[bot]`
- `ghost-docs[bot]`

## Trigger Event

### Pull Request

- `opened`
- `synchronize`
- `reopened`

## Requirement

- Branch Protection Enabled
- Status Checks > 0

## Custom Config

```yml:ghost-merge.yml
# ghost-merge.yml
owner: true

role:
  admin: true

user:
  - renovate[bot]
  - dependabot[bot]
  - ghost-docs[bot]
```

## App Permissions

### Repository

| Name             | Type    | Purpose                                |
| ---------------- | ------- | -------------------------------------- |
| `Administration` | `read`  | Check branch protection                |
| `Checks`         | `write` | Send status checks in repo             |
| `Contents`       | `write` | Merge PR                               |
| `Issues`         | `write` | Error logging                          |
| `Metadata`       | `read`  | Mandatory                              |
| `Pull requests`  | `write` | Enable auto-merge , Subscribe PR Event |

### Organization

| Name      | Type   | Purpose                  |
| --------- | ------ | ------------------------ |
| `Members` | `read` | Check author role in org |
