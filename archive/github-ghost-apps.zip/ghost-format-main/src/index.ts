import { octoflare } from 'octoflare'
import { scanner, string } from 'typescanner'

const isValidJson = scanner({
  scripts: scanner({
    format: string
  })
})

export default octoflare(async ({ payload, installation }) => {
  if (!installation) {
    return new Response('Skip Format: No Installation', {
      status: 200
    })
  }

  if (!('commits' in payload)) {
    return new Response('Skip Format: No Push Event', {
      status: 200
    })
  }

  const { repository, after, sender } = payload

  if (Number(after) === 0) {
    return new Response('Skip Format: Head SHA = 0', {
      status: 200
    })
  }

  const repo = repository.name
  const owner = repository.owner.login
  const ref = payload.ref.replace('refs/heads/', '')

  const { dispatchWorkflow } = await installation.createCheckRun({
    repo,
    owner,
    name: 'Ghost Format',
    head_sha: after
  })

  if (sender.name === 'ghost-format[bot]') {
    return {
      conclusion: 'skipped',
      output: {
        title: 'Skip Format',
        summary: 'Skipped Ghost Format because it was triggered by self.'
      }
    }
  }

  const response = (
    await installation.getFile('package.json', {
      ref,
      parser: (x) => {
        const json = JSON.parse(x)
        return isValidJson(json)
          ? 'valid'
          : {
              conclusion: 'skipped' as const,
              output: {
                title: 'No Format Command',
                summary: 'Format command not found in package.json.'
              }
            }
      }
    })
  )?.data ?? {
    conclusion: 'skipped',
    output: {
      title: 'No package.json',
      summary: 'Not found package.json in repo.'
    }
  }

  if (response !== 'valid') {
    return response
  }

  await dispatchWorkflow({ ref })

  return new Response('Ghost Format Workflow Dispatched', {
    status: 202
  })
})
