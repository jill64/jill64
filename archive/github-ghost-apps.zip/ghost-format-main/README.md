<!----- BEGIN GHOST DOCS LOGO src="./assets/logo.png" ----->

<div align="center">
<img src="./assets/logo.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# Ghost Format

[![ghost-format.yml](https://github.com/jill64/ghost-format/actions/workflows/ghost-format.yml/badge.svg)](https://github.com/jill64/ghost-format/actions/workflows/ghost-format.yml) [![github-app](https://img.shields.io/badge/GitHub_App-Ghost_Format-midnightblue)](https://github.com/apps/ghost-format) [![octoflare](https://img.shields.io/badge/framework-🌤️Octoflare-dodgerblue)](https://github.com/jill64/octoflare)

👻 Run Format, Auto Commit, In the Dark.

<!----- END GHOST DOCS HEADER ----->
