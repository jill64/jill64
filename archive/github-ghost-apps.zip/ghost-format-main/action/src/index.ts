import exec from '@actions/exec'
import { action } from 'octoflare/action'
import { retryAsync } from 'ts-retry'

action(async () => {
  const formatResult = await exec.getExecOutput('npm run format', undefined, {
    ignoreReturnCode: true
  })

  if (formatResult.exitCode !== 0) {
    return {
      conclusion: 'failure',
      output: {
        title: 'Format Failed',
        summary: `
## stdout
\`\`\`
${formatResult.stdout}
\`\`\`

## stderr
\`\`\`
${formatResult.stderr}
\`\`\
`
      }
    }
  }

  await exec.exec('git add -N .', undefined, {
    ignoreReturnCode: true
  })

  const diff = await exec.exec('git diff --exit-code', undefined, {
    ignoreReturnCode: true
  })

  if (diff === 0) {
    return
  }

  await exec.exec('git config user.name ghost-format[bot]')
  await exec.exec(
    'git config user.email 41898282+ghost-format[bot]@users.noreply.github.com'
  )

  await exec.exec('git add .')
  await exec.exec('git commit -m "chore: format"')

  try {
    await retryAsync(
      async () => {
        await exec.exec('git pull --rebase')
        await exec.exec('git push origin')
      },
      {
        delay: 1000,
        maxTry: 3
      }
    )
  } catch {
    return {
      conclusion: 'failure',
      output: {
        title: 'Push Failed',
        summary: 'Failed to push formatted code.'
      }
    }
  }

  return {
    conclusion: 'failure',
    output: {
      title: 'Auto Format Success',
      summary: 'Formatted code has been pushed.'
    }
  }
})
