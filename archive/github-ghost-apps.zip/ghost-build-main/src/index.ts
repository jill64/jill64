import { octoflare } from 'octoflare'
import { optional, scanner, string } from 'typescanner'

const isValidJson = scanner({
  scripts: scanner({
    build: optional(string)
  }),
  devDependencies: scanner({
    '@sveltejs/adapter-cloudflare': optional(string)
  })
})

export default octoflare(async ({ payload, installation }) => {
  if (!('commits' in payload)) {
    return new Response('Skip Build: No Push Event', {
      status: 200
    })
  }

  if (!installation) {
    return new Response('Skip Build: No Installation', {
      status: 200
    })
  }

  const head_sha = payload.after

  if (Number(head_sha) === 0) {
    return new Response('Skip Build: head SHA = 0', {
      status: 200
    })
  }

  const { repository, sender } = payload

  const owner = repository.owner.login
  const repo = repository.name
  const ref = payload.ref.replace('refs/heads/', '')

  const { dispatchWorkflow } = await installation.createCheckRun({
    owner,
    repo,
    name: 'Ghost Build',
    head_sha
  })

  if (sender.name === 'ghost-format[bot]') {
    return {
      conclusion: 'skipped',
      output: {
        title: 'Skip Build',
        summary: 'Skipped Ghost Build because it was triggered by ghost'
      }
    }
  }

  const response = (
    await installation.getFile('package.json', {
      ref,
      parser: (x) => {
        const json = JSON.parse(x)
        return isValidJson(json) &&
          json.scripts.build &&
          !json.devDependencies['@sveltejs/adapter-cloudflare']
          ? 'valid'
          : {
              conclusion: 'skipped' as const,
              output: {
                title: 'No Build Command',
                summary: 'Build command not found in package.json.'
              }
            }
      }
    })
  )?.data ?? {
    conclusion: 'skipped',
    output: {
      title: 'No package.json',
      summary: 'Not found package.json in repo.'
    }
  }

  if (typeof response !== 'string') {
    return response
  }

  await dispatchWorkflow({ ref })

  return new Response('Ghost Build Workflow Dispatched', {
    status: 202
  })
})
