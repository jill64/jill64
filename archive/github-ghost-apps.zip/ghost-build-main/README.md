<!----- BEGIN GHOST DOCS LOGO src="./assets/logo.png" ----->

<div align="center">
<img src="./assets/logo.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# Ghost Build

[![ghost-build.yml](https://github.com/jill64/ghost-build/actions/workflows/ghost-build.yml/badge.svg)](https://github.com/jill64/ghost-build/actions/workflows/ghost-build.yml) [![github-app](https://img.shields.io/badge/GitHub_App-Ghost_Build-midnightblue)](https://github.com/apps/ghost-build) [![octoflare](https://img.shields.io/badge/framework-🌤️Octoflare-dodgerblue)](https://github.com/jill64/octoflare)

👻 Run Build, Regenerate Artifact, In the Dark.

<!----- END GHOST DOCS HEADER ----->

## Build

| Event | Command         |
| ----- | --------------- |
| Push  | `npm run build` |

## Regenerate Artifact

Push commit when exist `git diff` output after build.
