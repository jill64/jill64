import { build } from 'esbuild'

await build({
  entryPoints: ['action/src/index.ts'],
  bundle: true,
  outfile: 'action/dist/index.cjs',
  platform: 'node',
  target: 'node20'
})
