import exec from '@actions/exec'
import { action } from 'octoflare/action'
import { retryAsync } from 'ts-retry'

action(async () => {
  const buildResult = await exec.getExecOutput('npm run build', undefined, {
    ignoreReturnCode: true
  })

  if (buildResult.exitCode !== 0) {
    return {
      conclusion: 'failure',
      output: {
        title: 'Build Failed',
        summary: `
## stdout
\`\`\`
${buildResult.stdout.replaceAll('`', '`')}

## stderr
\`\`\`
${buildResult.stderr.replaceAll('`', '`')}
\`\`\`
`
      }
    }
  }

  await exec.exec('git add -N .')

  const diff = await exec.exec('git diff --exit-code', undefined, {
    ignoreReturnCode: true
  })

  if (diff === 0) {
    return
  }

  await exec.exec('git config user.name ghost-build[bot]')
  await exec.exec(
    'git config user.email 41898282+ghost-build[bot]@users.noreply.github.com'
  )

  await exec.exec('git add .')
  await exec.exec('git commit -m "chore: regenerate artifacts"')

  try {
    await retryAsync(
      async () => {
        await exec.exec('git pull --rebase')
        await exec.exec('git push origin')
      },
      {
        delay: 1000,
        maxTry: 3
      }
    )
  } catch {
    return {
      conclusion: 'failure',
      output: {
        title: 'Push Failed',
        summary: 'Failed to push artifact.'
      }
    }
  }

  return {
    conclusion: 'failure',
    output: {
      title: 'Regenerated Artifact',
      summary: 'The updated artifact will be pushed shortly.'
    }
  }
})
