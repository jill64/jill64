<!----- BEGIN GHOST DOCS LOGO src="./assets/logo.png" ----->

<div align="center">
<img src="./assets/logo.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# Ghost Lint

[![ghost-lint.yml](https://github.com/jill64/ghost-lint/actions/workflows/ghost-lint.yml/badge.svg)](https://github.com/jill64/ghost-lint/actions/workflows/ghost-lint.yml) [![github-app](https://img.shields.io/badge/GitHub_App-Ghost_Lint-midnightblue)](https://github.com/apps/ghost-lint) [![octoflare](https://img.shields.io/badge/framework-🌤️Octoflare-dodgerblue)](https://github.com/jill64/octoflare)

👻 Run Lint, Auto Fix, In the Dark.

<!----- END GHOST DOCS HEADER ----->

## Lint

| Event | Command        |
| ----- | -------------- |
| Push  | `npm run lint` |

## Auto Fix

### Unused Dependencies

| Assumption     | Trigger                | Fix                                                       |
| -------------- | ---------------------- | --------------------------------------------------------- |
| `npx depcheck` | Unused dependencies    | Delete target package from `package.json`.dependencies    |
| `npx depcheck` | Unused devDependencies | Delete target package from `package.json`.devDependencies |
