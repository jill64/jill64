import { octoflare } from 'octoflare'
import { scanner, string } from 'typescanner'

const isValidJson = scanner({
  scripts: scanner({
    lint: string
  })
})

export default octoflare(async ({ payload, installation }) => {
  if (!installation) {
    return new Response('Skip Lint: No Installation', {
      status: 200
    })
  }

  if (!('commits' in payload)) {
    return new Response('Skip Lint: No Push Event', {
      status: 200
    })
  }

  const { repository } = payload

  const head_sha = payload.after

  if (Number(head_sha) === 0) {
    return new Response('Skip Lint: head SHA = 0', {
      status: 200
    })
  }

  const owner = repository.owner.login
  const repo = repository.name
  const ref = payload.ref.replace('refs/heads/', '')

  const { dispatchWorkflow } = await installation.createCheckRun({
    owner,
    repo,
    name: 'Ghost Lint',
    head_sha
  })

  const response = (
    await installation.getFile('package.json', {
      ref,
      parser: (x) => {
        const json = JSON.parse(x)
        return isValidJson(json)
          ? 'valid'
          : {
              conclusion: 'skipped' as const,
              output: {
                title: 'No Lint Command',
                summary: 'Lint command not found in package.json.'
              }
            }
      }
    })
  )?.data ?? {
    conclusion: 'skipped',
    output: {
      title: 'No package.json',
      summary: 'Not found package.json in repo.'
    }
  }

  if (response !== 'valid') {
    return response
  }

  await dispatchWorkflow({ ref })

  return new Response('Ghost Lint Workflow Dispatched', {
    status: 202
  })
})
