import exec from '@actions/exec'
import { action } from 'octoflare/action'
import { correctDepcheckError } from './correctDepcheckError.js'

action(async () => {
  const lintResult = await exec.getExecOutput('npm run lint', undefined, {
    ignoreReturnCode: true
  })

  if (lintResult.exitCode === 0) {
    return
  }

  const isDepcheckError =
    lintResult.stdout.includes('Unused dependencies') ||
    lintResult.stdout.includes('Unused devDependencies')

  if (isDepcheckError) {
    return await correctDepcheckError()
  }

  return {
    conclusion: 'failure',
    output: {
      title: 'Lint Failed',
      summary: `
## stdout
\`\`\`
${lintResult.stdout}
\`\`\`

## stderr
\`\`\`
${lintResult.stderr}
\`\`\`
`
    }
  }
})
