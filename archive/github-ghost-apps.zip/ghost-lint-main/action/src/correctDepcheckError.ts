import exec from '@actions/exec'
import { writeFile } from 'fs/promises'
import { CloseCheckParam } from 'octoflare'
import { array, optional, scanner, string } from 'typescanner'
import { pushOrigin } from './util/pushOrigin.js'
import { attempt } from '@jill64/attempt'

export const correctDepcheckError = async (): Promise<CloseCheckParam> => {
  const { stdout: packageJsonStr } = await exec.getExecOutput(
    'cat package.json',
    undefined,
    {
      ignoreReturnCode: true
    }
  )

  const packageJson = attempt(() => JSON.parse(packageJsonStr) as unknown, null)

  const isValidPackageJson = scanner({
    dependencies: optional(scanner({})),
    devDependencies: optional(scanner({}))
  })

  if (!isValidPackageJson(packageJson)) {
    return {
      conclusion: 'failure',
      output: {
        title: 'Invalid Package.json',
        summary: JSON.stringify(packageJson, null, 2)
      }
    }
  }

  const depcheckResult = await exec.getExecOutput(
    'npx depcheck --json',
    undefined,
    {
      ignoreReturnCode: true
    }
  )

  const result = JSON.parse(depcheckResult.stdout)

  const isValidResult = scanner({
    dependencies: array(string),
    devDependencies: array(string)
  })

  if (!isValidResult(result)) {
    return {
      conclusion: 'failure',
      output: {
        title: 'Invalid Depcheck Result',
        summary: depcheckResult.stdout
      }
    }
  }

  const omittedDeps = Object.fromEntries(
    Object.entries(packageJson.dependencies ?? {}).filter(
      ([key]) => !result.dependencies.includes(key)
    )
  )

  const omittedDevDeps = Object.fromEntries(
    Object.entries(packageJson.devDependencies ?? {}).filter(
      ([key]) => !result.devDependencies.includes(key)
    )
  )

  const omittedPackageJson = {
    ...packageJson,
    ...(Object.keys(omittedDeps).length ? { dependencies: omittedDeps } : {}),
    ...(Object.keys(omittedDevDeps).length
      ? { devDependencies: omittedDevDeps }
      : {})
  }

  await writeFile('package.json', JSON.stringify(omittedPackageJson, null, 2))

  await pushOrigin('fix: omit unused dependencies')

  return {
    conclusion: 'failure',
    output: {
      title: 'Omitted Unused Dependencies',
      summary: 'New package.json has been pushed.'
    }
  }
}
