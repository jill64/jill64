import exec from '@actions/exec'
import { retryAsync } from 'ts-retry'

export const pushOrigin = async (message: string) => {
  await exec.exec('git config user.name ghost-lint[bot]')
  await exec.exec(
    'git config user.email 41898282+ghost-lint[bot]@users.noreply.github.com'
  )

  await exec.exec('git add .')
  await exec.exec(`git commit -m "${message}"`)

  try {
    await retryAsync(
      async () => {
        await exec.exec('git pull --rebase')
        await exec.exec('git push origin')
      },
      {
        delay: 1000,
        maxTry: 3
      }
    )
  } catch {
    return {
      conclusion: 'failure',
      output: {
        title: 'Push Failed',
        summary: 'Failed to push formatted code.'
      }
    }
  }
}
