<!----- BEGIN GHOST DOCS LOGO src="./assets/logo.png" ----->

<div align="center">
<img src="./assets/logo.png" width="100px" />
</div>

<!----- END GHOST DOCS LOGO ----->

<!----- BEGIN GHOST DOCS HEADER ----->

# codespace-closer

<!----- BEGIN GHOST DOCS BADGES -----><a href="https://github.com/apps/codespace-closer"><img src="https://img.shields.io/website?up_message=working&down_message=down&url=https%3A%2F%2Fgithub.com%2Fapps%2Fcodespace-closer" alt="website" /></a><!----- END GHOST DOCS BADGES ----->

🖥️ Delete codespaces on branch deleted

<!----- END GHOST DOCS HEADER ----->

## Environment Variable

Required UAT by GitHub REST API limitation.

| KEY          | Description                             |
| ------------ | --------------------------------------- |
| `GITHUB_UAT` | User Access Token (codespace,admin:org) |

<!----- BEGIN GHOST DOCS FOOTER -----><!----- END GHOST DOCS FOOTER ----->
