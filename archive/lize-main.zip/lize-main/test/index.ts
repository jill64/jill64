import 'dotenv/config'
import { env } from 'node:process'
import { main } from '../src/main.js'

main({
  GENTIANA_PASSWORD: env.GENTIANA_PASSWORD!,
  LI_ZE_HR_PASSWORD: [
    env.LI_ZE_HR0_PASSWORD!,
    env.LI_ZE_HR1_PASSWORD!,
    env.LI_ZE_HR2_PASSWORD!,
    env.LI_ZE_HR3_PASSWORD!,
    env.LI_ZE_HR4_PASSWORD!,
    env.LI_ZE_HR5_PASSWORD!,
    env.LI_ZE_HR6_PASSWORD!,
    env.LI_ZE_HR7_PASSWORD!,
    env.LI_ZE_HR8_PASSWORD!,
    env.LI_ZE_HR9_PASSWORD!
  ]
})
