import { AppBskyFeedDefs, BskyAgent } from '@atproto/api'
import dayjs from 'dayjs'

export const main = async (credential: {
  GENTIANA_PASSWORD: string
  LI_ZE_HR_PASSWORD: string[]
}) => {
  const li_ze = new BskyAgent({
    service: 'https://bsky.social'
  })
  const identifier = {
    gentiana: 'gent1ana.bsky.social',
    li_ze_hr: [
      'li-ze-hr-0.bsky.social',
      'li-ze-hr-1.bsky.social',
      'li-ze-hr-2.bsky.social',
      'li-ze-hr-3.bsky.social',
      'li-ze-hr-4.bsky.social',
      'li-ze-hr-5.bsky.social',
      'li-ze-hr-6.bsky.social',
      'li-ze-hr-7.bsky.social',
      'li-ze-hr-8.bsky.social',
      'li-ze-hr-9.bsky.social'
    ]
  }

  const prefix = '【LiZe Health Report】'
  const command_prefix = '/lz'

  const lize_index = dayjs().minute() % 10

  await li_ze.login({
    identifier: identifier.li_ze_hr[lize_index],
    password: credential.LI_ZE_HR_PASSWORD[lize_index]
  })

  type PostRecord =
    | {
        text: string
      }
    | undefined

  const listPosts = async (
    cursor?: string
  ): Promise<AppBskyFeedDefs.FeedViewPost[]> => {
    const {
      data: { feed, cursor: next_cursor }
    } = await li_ze.getAuthorFeed({
      actor: identifier.gentiana,
      cursor
    })

    const cont =
      next_cursor &&
      !feed.find(
        (item) =>
          item.post.author.handle === identifier.gentiana &&
          (item.post.record as PostRecord)?.text.startsWith(prefix)
      )

    const next_list = cont ? await listPosts(next_cursor) : []

    return [
      ...feed.filter((x) => x.post.author.handle === identifier.gentiana),
      ...next_list
    ]
  }

  const list = await listPosts()

  const health_report = list.find((item) =>
    (item.post.record as PostRecord)?.text.startsWith(prefix)
  )

  const health_report_indexed_at = dayjs(
    health_report?.post?.indexedAt ?? '2021-01-02'
  )

  const command = list.find((item) =>
    (item.post.record as PostRecord)?.text.startsWith(command_prefix)
  )

  const run_command = dayjs(health_report_indexed_at).isBefore(
    command?.post?.indexedAt ?? '2021-01-01'
  )

  const cont = run_command
    ? true
    : dayjs().subtract(12, 'hours').isAfter(health_report_indexed_at)

  if (!cont) {
    console.log(
      'No need to run the command. The last health report is up to date.'
    )
    return
  }

  const match_list = list.filter(
    (item) =>
      dayjs(item.post.indexedAt).isAfter(health_report_indexed_at) &&
      (item.post.record as PostRecord)?.text.match(/[\+\-]\d*$/)
  )

  const parseNumber = (regex: RegExpMatchArray | undefined | null) => {
    if (!regex) {
      return 0
    }

    const [, symbol, num] = regex
    return parseInt(num) * (symbol === '-' ? -1 : 1)
  }

  const base_energy = parseNumber(
    (health_report?.post.record as PostRecord)?.text.match(
      /^【LiZe Health Report】エネルギー ([\+\-]?)(\d*)$/
    )
  )

  const sum = match_list
    .map((item) =>
      parseNumber(
        (item.post.record as PostRecord)?.text.match(/([\+\-])(\d*)$/)
      )
    )
    .reduce((acc, cur) => acc + cur, base_energy)

  const gentiana = new BskyAgent({
    service: 'https://bsky.social'
  })

  await gentiana.login({
    identifier: identifier.gentiana,
    password: credential.GENTIANA_PASSWORD
  })

  const text = `${prefix}エネルギー ${sum >= 0 ? '+' : '-'}${Math.abs(sum)}`

  if (run_command && command) {
    gentiana.post({
      text,
      reply: {
        root: command.post,
        parent: command.post
      }
    })
  } else {
    await gentiana.post({
      text
    })
  }
}
