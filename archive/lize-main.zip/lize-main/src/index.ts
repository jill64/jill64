import { main } from './main.js'

interface Env {
  GENTIANA_PASSWORD: string
  LI_ZE_HR0_PASSWORD: string
  LI_ZE_HR1_PASSWORD: string
  LI_ZE_HR2_PASSWORD: string
  LI_ZE_HR3_PASSWORD: string
  LI_ZE_HR4_PASSWORD: string
  LI_ZE_HR5_PASSWORD: string
  LI_ZE_HR6_PASSWORD: string
  LI_ZE_HR7_PASSWORD: string
  LI_ZE_HR8_PASSWORD: string
  LI_ZE_HR9_PASSWORD: string
}

export default {
  async scheduled(_: ScheduledEvent, env: Env): Promise<void> {
    await main({
      GENTIANA_PASSWORD: env.GENTIANA_PASSWORD,
      LI_ZE_HR_PASSWORD: [
        env.LI_ZE_HR0_PASSWORD,
        env.LI_ZE_HR1_PASSWORD,
        env.LI_ZE_HR2_PASSWORD,
        env.LI_ZE_HR3_PASSWORD,
        env.LI_ZE_HR4_PASSWORD,
        env.LI_ZE_HR5_PASSWORD,
        env.LI_ZE_HR6_PASSWORD,
        env.LI_ZE_HR7_PASSWORD,
        env.LI_ZE_HR8_PASSWORD,
        env.LI_ZE_HR9_PASSWORD
      ]
    })
  }
}
