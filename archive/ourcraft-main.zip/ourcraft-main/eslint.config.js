import { svelteTsConfig } from '@jill64/eslint-config-svelte'

/** @type {import('@jill64/eslint-config-svelte').FlatConfig[]} */
export default svelteTsConfig({
  svelteRules: {
    'svelte/valid-compile': 'off'
  }
})
