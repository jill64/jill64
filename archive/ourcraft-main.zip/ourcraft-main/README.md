# ourcraft

⛏️ Minecraft multiplayer server on AWS with web console
