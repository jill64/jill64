import { onRender } from '@jill64/svelte-suite'

export const handle = onRender()
