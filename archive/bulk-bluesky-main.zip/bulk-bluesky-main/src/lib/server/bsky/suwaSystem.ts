import { SUWASYSTEM_PASSWORD } from '$env/static/private'
import { bsky } from '../bsky'

export const suwasystem = bsky({
  username: 'suwasystem.com',
  password: SUWASYSTEM_PASSWORD
})
