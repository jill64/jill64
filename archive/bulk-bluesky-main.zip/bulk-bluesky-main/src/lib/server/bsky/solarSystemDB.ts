import { SOLARSYSTEMDB_PASSWORD } from '$env/static/private'
import { bsky } from '../bsky'

export const solarsystemdb = bsky({
  username: 'solarsystemdb.com',
  password: SOLARSYSTEMDB_PASSWORD
})
