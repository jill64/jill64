import { PC_FLEX_PASSWORD } from '$env/static/private'
import { bsky } from '../bsky'

export const pcFlex = bsky({
  username: 'pc-flex.suwasystem.com',
  password: PC_FLEX_PASSWORD
})
