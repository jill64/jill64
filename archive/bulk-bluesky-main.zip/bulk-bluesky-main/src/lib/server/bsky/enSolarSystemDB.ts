import { EN_SOLARSYSTEMDB_PASSWORD } from '$env/static/private'
import { bsky } from '../bsky'

export const enSolarsystemdb = bsky({
  username: 'en.solarsystemdb.com',
  password: EN_SOLARSYSTEMDB_PASSWORD
})
