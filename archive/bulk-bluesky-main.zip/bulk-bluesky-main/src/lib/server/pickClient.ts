import type { Client } from '$lib/client'
import { enSolarsystemdb } from './bsky/enSolarSystemDB'
import { pcFlex } from './bsky/pcFlex'
import { solarsystemdb } from './bsky/solarSystemDB'
import { suwasystem } from './bsky/suwaSystem'

export const pickClient = (path: Client) => {
  if (path === 'suwasystem.com') return suwasystem
  if (path === 'solarsystemdb.com') return solarsystemdb
  if (path === 'en.solarsystemdb.com') return enSolarsystemdb
  if (path === 'pc-flex.suwasystem.com') return pcFlex
  throw new Error('Invalid client')
}
