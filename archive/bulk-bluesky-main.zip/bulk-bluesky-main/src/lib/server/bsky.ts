import { Agent, CredentialSession } from '@atproto/api'
import type { ProfileView } from '@atproto/api/dist/client/types/app/bsky/actor/defs'
import { wait } from '../wait'

export const bsky = async ({
  username,
  password
}: {
  username: string
  password: string
}) => {
  const session = new CredentialSession(new URL('https://bsky.social'))

  await session.login({
    identifier: username,
    password: password
  })

  const agent = new Agent(session)

  return {
    getAllFollowers: async (actor: string) => {
      let cursor: string | undefined = ''
      let results: ProfileView[] = []

      while (cursor !== undefined) {
        const result = await agent.getFollowers({
          actor,
          limit: 100,
          cursor
        })

        console.log(
          `Get followers for ${actor} count ${result.data.followers.length}`
        )

        results.push(...result.data.followers)
        cursor = result.data.cursor
      }

      return results
    },
    follow: async (did: string) => {
      await agent.follow(did)
    },
    getInfo: async (actor: string) => {
      const result = await agent.getProfile({
        actor
      })

      return result.data
    },
    getAllFollows: async () => {
      let cursor: string | undefined = ''
      let results: ProfileView[] = []

      while (cursor !== undefined) {
        const result = await agent.getFollows({
          actor: username,
          limit: 100,
          cursor
        })

        console.log(
          `Get follows for ${username} count ${result.data.follows.length}`
        )

        results.push(...result.data.follows)
        cursor = result.data.cursor
      }

      return results
    }
  }
}
