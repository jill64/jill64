export type Client =
  | 'suwasystem.com'
  | 'solarsystemdb.com'
  | 'en.solarsystemdb.com'
  | 'pc-flex.suwasystem.com'
