<script lang="ts">
  import {
    FlipButton,
    ThemeManager,
    Toaster,
    theme
  } from '@jill64/svelte-suite'
  import '../app.postcss'
</script>

<ThemeManager />
<Toaster dark={theme.isDark} />

<svelte:head>
  <link rel="icon" href="favicon.png" />
  <link rel="apple-touch-icon" href="favicon.png" />
  <title>Bulk Bluesky</title>
  <meta name="description" content="🦋 Automating bulk follow task" />
</svelte:head>

<header class="flex justify-between p-2">
  <h1 class="font-bold text-xl">Bulk Bluesky</h1>
  <FlipButton />
</header>

<slot />
