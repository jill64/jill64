import { ok } from '$lib/server/ok.js'
import { pickClient } from '$lib/server/pickClient.js'
import { json } from '@sveltejs/kit'

export const GET = async ({ params: { target, client } }) => {
  const bsky = await pickClient(client)
  const res = await bsky.getInfo(target)

  return json(res)
}

export const POST = async ({ params: { target, client } }) => {
  const bsky = await pickClient(client)
  await bsky.follow(target)
  return ok
}
