import { pickClient } from '$lib/server/pickClient'
import { json } from '@sveltejs/kit'

export const GET = async ({ params: { client, target } }) => {
  const bsky = await pickClient(client)
  const result = await bsky.getAllFollowers(target)
  return json(result)
}
