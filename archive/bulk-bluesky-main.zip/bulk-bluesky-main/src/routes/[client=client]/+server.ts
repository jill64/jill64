import { pickClient } from '$lib/server/pickClient'
import { json } from '@sveltejs/kit'

export const GET = async ({ params: { client } }) => {
  const bsky = await pickClient(client)
  const res = await bsky.getAllFollows()

  return json(res)
}
