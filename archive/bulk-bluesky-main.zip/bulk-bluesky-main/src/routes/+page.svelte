<script lang="ts">
  import { browser } from '$app/environment'
  import { wait } from '$lib/wait'
  import type {
    ProfileView,
    ProfileViewDetailed
  } from '@atproto/api/dist/client/types/app/bsky/actor/defs'
  import { CheckCircleIcon } from '@jill64/svelte-suite/icons'
  import { Select } from '@jill64/svelte-suite/input'

  const list = [
    'suwasystem.com',
    'solarsystemdb.com',
    'en.solarsystemdb.com',
    'pc-flex.suwasystem.com'
  ]

  let target = $state('')
  let client = $state<(typeof list)[number]>('suwasystem.com')

  let target_info = $derived.by<Promise<ProfileViewDetailed>>(async () => {
    if (browser) {
      const res = await fetch(`/${client}/${target}`)
      return await res.json()
    }
    return null
  })

  $effect(() => {
    fetch(`/${client}`)
      .then((res) => res.json())
      .then((list) => {
        followed_did = new Set(list.map((x: ProfileView) => x.did))
      })
  })

  let all_followers = $derived.by<Promise<ProfileViewDetailed[]>>(async () => {
    if (browser) {
      const res = await fetch(`/${client}/${target}/followers`)
      return await res.json()
    }
    return []
  })

  let followed_did = $state<Set<string>>(new Set())
</script>

<main class="flex flex-wrap justify-around gap-8 items-start">
  <Select
    bind:value={client}
    {list}
    Class="bg-inherit border rounded border-gray-500"
  />
  followed_did : {followed_did.size}
  <input
    bind:value={target}
    class="border-b border-gray-500 focus:border-b-2 outline-none bg-inherit"
  />
  <div class="flex items-center gap-4">
    {#await target_info then info}
      <img src={info.avatar} alt="avatar" class="rounded-full" width="50px" />
      <hgroup>
        <h2 class="text-xl font-bold">{info.displayName}</h2>
        <p class="text-gray-500">{info.handle}</p>
      </hgroup>
    {/await}
  </div>
  {#await all_followers then all_followers}
    <button
      class="bg-blue-500 text-white font-bold px-4 py-2 rounded-full push dark:pop-effect"
      onclick={async () => {
        for (const follower of all_followers) {
          if (followed_did.has(follower.did)) {
            console.log(`Already followed ${follower.displayName}`)
            continue
          }
          await fetch(`/${client}/${follower.did}`, { method: 'POST' })
          console.log(`Followed ${follower.displayName}`)
          await wait(100)
          followed_did.add(target)
        }
      }}
    >
      Follow All
    </button>
  {/await}
  {#await all_followers then followers}
    <ul>
      {#each followers.filter((x) => x.did) as follower}
        <li class="flex items-center gap-4">
          {#if followed_did.has(follower.did)}
            <CheckCircleIcon class="text-green-500" />
          {:else}
            <div class="w-6"></div>
          {/if}
          <img
            src={follower.avatar}
            alt="avatar"
            class="rounded-full"
            width="20px"
          />
          <hgroup>
            <h3 class="font-bold">{follower.displayName}</h3>
            <p class="text-gray-500">{follower.handle}</p>
          </hgroup>
        </li>
      {/each}
    </ul>
  {/await}
</main>
