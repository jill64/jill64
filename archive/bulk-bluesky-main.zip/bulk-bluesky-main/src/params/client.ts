export const match = (path: string) =>
  path === 'suwasystem.com' ||
  path === 'solarsystemdb.com' ||
  path === 'en.solarsystemdb.com' ||
  path === 'pc-flex.suwasystem.com'
