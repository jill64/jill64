import { toast } from '@jill64/svelte-suite'

export const handleError = (e) => {
  if (e.error instanceof Error) {
    toast.error(e.error.message)
  }
}
