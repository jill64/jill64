# bulk-bluesky

🦋 Automating bulk follow task
