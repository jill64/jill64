<!----- BEGIN GHOST DOCS HEADER ----->

# trivial-snippets-og-image

[![deploy.yml](https://github.com/jill64/trivial-snippets-og-image/actions/workflows/deploy.yml/badge.svg)](https://github.com/jill64/trivial-snippets-og-image/actions/workflows/deploy.yml)

Dynamic OG-Image generation API for Trivial Snippets

<!----- END GHOST DOCS HEADER ----->
