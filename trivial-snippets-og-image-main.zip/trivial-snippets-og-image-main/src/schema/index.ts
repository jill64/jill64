interface Article {
  uid: string
  title: string
}

export interface DB {
  article: Article
}
