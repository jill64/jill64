import { Kysely } from 'kysely'
import { D1Dialect } from 'kysely-d1'
import { DB } from '../schema'
import { Env } from '../types/Env'

export const getTitle = async ({
  request,
  env
}: {
  request: Request
  env: Env
}) => {
  const uid = new URL(request.url).pathname.split('/')[1]

  if (!uid) {
    return null
  }

  return env.D1
    ? await new Kysely<DB>({
        dialect: new D1Dialect({ database: env.D1 })
      })
        .selectFrom('article')
        .select('title')
        .where('uid', '=', uid)
        .executeTakeFirst()
        .then((row) => row?.title)
    : 'Test'
}
