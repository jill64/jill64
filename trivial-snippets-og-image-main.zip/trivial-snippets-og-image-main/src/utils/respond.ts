import { Resvg } from '@resvg/resvg-wasm'

export const respond = (svg: string) => {
  const resvg = new Resvg(svg)
  const pngData = resvg.render()
  const pngBuffer = pngData.asPng()

  return new Response(pngBuffer, {
    headers: {
      'Content-Type': 'image/png'
    }
  })
}
