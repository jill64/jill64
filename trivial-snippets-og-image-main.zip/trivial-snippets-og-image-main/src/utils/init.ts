import { initWasm } from '@resvg/resvg-wasm'
import { init as initSatori } from 'satori/wasm'
import initYoga from 'yoga-wasm-web'
import resvgWasm from '../vender/resvg.wasm'
import yogaWasm from '../vender/yoga.wasm'

let isInit = false

export const init = async () => {
  if (!isInit) {
    initSatori(await initYoga(yogaWasm))
    await initWasm(resvgWasm)
    isInit = true
  }
}
