import { unfurl } from '@jill64/unfurl'
import React from 'react'
import satori from 'satori/wasm'
import { Env } from './types/Env'
import { getTitle } from './utils/getTitle'
import { init } from './utils/init'
import { loadGoogleFont } from './utils/loadGoogleFont'
import { respond } from './utils/respond'

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const { noto, title, helvetica, helveticaBold } = await unfurl(
      {
        title: getTitle({ request, env }),
        noto: loadGoogleFont({
          family: 'Noto Sans JP'
        }),
        helvetica: loadGoogleFont({
          family: 'Helvetica'
        }),
        helveticaBold: loadGoogleFont({
          family: 'Helvetica',
          weight: 700
        })
      },
      init()
    )

    if (!title) {
      return new Response(null, { status: 404 })
    }

    const svg = await satori(
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          background: '#161616'
        }}
      >
        <div
          style={{
            top: '64px',
            bottom: '108px',
            left: '64px',
            right: '64px',
            borderRadius: '8px',
            position: 'absolute',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            background: '#EEE',
            padding: '32px'
          }}
        >
          <div
            style={{
              fontSize: '64px',
              color: '#000',
              fontFamily: 'Noto',
              lineClamp: 4
            }}
          >
            {title}
          </div>
        </div>
        <div
          style={{
            position: 'absolute',
            display: 'flex',
            alignItems: 'flex-end',
            bottom: '32px',
            right: '48px',
            fontSize: '32px',
            color: '#EEE',
            fontFamily: 'Helvetica Bold',
            gap: '4px'
          }}
        >
          <span
            style={{
              fontSize: '48px',
              color: '#EEE',
              fontFamily: 'Helvetica Bold'
            }}
          >
            {'<T/>'}
          </span>
          rivial Snippets
        </div>
      </div>,
      {
        width: 1200,
        height: 630,
        fonts: [
          {
            name: 'Noto',
            data: noto
          },
          {
            name: 'Helvetica',
            data: helvetica
          },
          {
            name: 'Helvetica Bold',
            data: helveticaBold
          }
        ]
      }
    )

    return respond(svg)
  }
}
