declare module '*.wasm' {
  export default ArrayBuffer
}

declare module '*.ttf' {
  export default ArrayBuffer
}

declare module '*.otf' {
  export default ArrayBuffer
}
